<?php
/**
 * @var KOAO_Theme $theme
 * @var KOAO_Agency $agency
 */

$theme->the_header_html();
$theme->the_template( 'agency-type-header' );

$agency = new KOAO_Agency( $post );

?>

<div class="columns small-12">

	<h1 class="text-center"><?php esc_html_e( 'Agency Details', 'koao-theme' ); ?></h1>

	<div class="agency-type-inlay card">
		<div class="row">
			<div class="columns large-6 medium-12">
				<div class="row">

					<div class="columns medium-4">
						<?php $agency->the_featured_image_html( 'koao-section-thumb' ); ?>
					</div>

					<div class="columns medium-8">
						<div class="text-center">
							<div class="agency-name"><?php $agency->the_agency_name_html(); ?></div>
							<div class="agency-details">
								<div class="agency-category"><?php $agency->the_agency_types_html(); ?></div>
								<div class="agency-subcategory"><?php $agency->the_subcategory_html(); ?></div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="columns large-6 medium-12">
				<ul class="small-block-grid-1 medium-block-grid-2 agency-contact-info">
					<li>
						<span class="title"><?php esc_html_e( 'Office Address', 'koao-theme' ); ?></span><br>
						<?php $agency->the_template('card/agency-address'); ?>
					</li>
					<li>
						<span class="title"><?php esc_html_e( 'Contact', 'koao-theme' ); ?></span><br>
						<?php $agency->the_contact_name_html(); ?><br>
						<?php $agency->the_contact_email_html(); ?>
					</li>
					<li>
						<span class="title"><?php esc_html_e( 'Office Phone', 'koao-theme' ); ?></span><br>
						<?php $agency->the_office_phone_html(); ?>
					</li>
					<li>
						<span class="title"><?php esc_html_e( 'Web', 'koao-theme' ); ?></span><br>
						<?php $agency->the_url(); ?>
					</li>
				</ul>
			</div>
		</div>
	</div>

	<ul class="small-block-grid-1 medium-block-grid-2">

		<?php if ( $agency->has_work_samples() ) : ?>
			<li class="column">

				<div class="card">

					<p class="title"><?php esc_html_e( 'Work Samples', 'koao-theme' ); ?></p>

					<ul class="small-block-grid-1 medium-block-grid-2 large-block-grid-3">
					<?php foreach ( $agency->work_samples() as $work_sample ) : ?>
						<li class="jq-work-sample" type="<?php esc_html_e('Click to view sample images from this project', 'koao-theme')?>">
							<?php $work_sample->the_featured_image_html('koao-card-thumb'); ?>
							<div class="jq-magnific-popup mfp-hide">
								<?php $work_sample->the_attached_images_html(); ?>
							</div>
						</li>
					<?php endforeach; ?>
					</ul>

				</div>

			</li>
		<?php endif; ?>

		<li class="column">
			<div class="card">
				<p class="title"><?php esc_html_e( 'Agreements', 'koao-theme' ); ?></p>

				<ul class="small-block-grid-1 medium-block-grid-2">

					<li>
						<p>
							<span class="title"><?php esc_html_e( 'Master Agreement', 'koao-theme' ); ?></span><br>
							<?php $agency->the_agreement_type_html(); ?>
						</p>

						<div class="row">
							<div class="columns small-12 medium-6">
								<div class="title"><?php esc_html_e( 'Start Date', 'koao-theme' ); ?></div>
								<?php $agency->the_start_date_html(); ?>
							</div>
							<div class="columns small-12 medium-6">
								<div class="title"><?php esc_html_e( 'End Date', 'koao-theme' ); ?></div>
								<?php $agency->the_end_date_html(); ?>
							</div>
						</div>
					</li>

					<li>
						<div class="title"><?php esc_html_e( 'Authorized Services', 'koao-theme' ); ?></div>
						<?php $agency->the_authorized_services_html(); ?>
					</li>

				</ul>

			</div>
		</li>
		<?php if ( $agency->has_service_rates() && KOAO::current_user_can_download_roster_files() ) : ?>
		<li>
			<div class="card">
				<p class="title"><?php esc_html_e( 'Agency Rates', 'koao-theme' ); ?></p>
				<ul class="roster">
				<?php foreach ( $links = $agency->service_rate_urls() as $service_name => $url ) : ?>
					<li>
					<?php WPLib::the_link(
						$url,
						WPLib::get_img( KOAO::get_themeable_asset_url('csv-file-type-icon' ) )
						.
						sprintf( '<div>%s</div>', esc_html( $service_name ) )
					); ?>
					</li>
				<?php endforeach; ?>
				</ul>
			</div>
		</li>
		<?php endif; ?>
	</ul>
</div>

<?php

$theme->the_footer_html();
