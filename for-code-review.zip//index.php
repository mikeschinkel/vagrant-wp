<?php
/**
 * @var KOAO_Theme $theme
 */

	$theme->the_header_html();
	_e( 'Page Template Not Configured for this URL', 'koao-theme' );
	$theme->the_footer_html();
