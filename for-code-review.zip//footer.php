			</main>

			<?php get_footer( 'content' ); ?>

		</div>

		<?php wp_footer(); ?>
	</body>

</html>