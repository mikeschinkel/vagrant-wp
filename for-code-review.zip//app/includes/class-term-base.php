<?php

/**
 * Class KOAO_Term_Base
 *
 * @mixin KOAO_Term_Model_Base
 * @mixin KOAO_Term_View_Base
 *
 */
class KOAO_Term_Base extends WPLib_Term_Base {

}
