<?php

/**
 * Class KOAO_Term_Model_Base
 *
 * @mixin KOAO_Term_View_Base
 *
 * @method KOAO_Term_View_Base view()
 */
class KOAO_Term_Model_Base extends WPLib_Term_Model_Base {

	/**
	 * @return bool
	 */
	function has_image() {
		return $this->has_term() && $this->image_url();
	}

	/**
	 * Get URL of taxonomy image.
	 *
	 * @return string
	 */
	function image_url() {
		return $this->get_image_url();
	}

	/**
	 * Update taxonomy image extended field.
	 * Note, the image does not need to be from the Media library.
	 *
	 * @param $image_url string URL of an image.
	 *
	 * @return bool true if successful
	 */
	function update_image_url( $image_url ) {

		return $this->update_meta_value( 'image_url', $image_url, 'url' );
	}

	/**
	 * Get URL for the thumbnail version of the taxonomy image.
	 *
	 * @return string
	 */
	function thumbnail_url() {

		return $this->get_thumbnail_url();

	}
	/**
	 * Get URL for the thumbnail version of the taxonomy image (or a default image if $use_default === true ).
	 *
	 * @param string|array $args {
	 *
	 *      @type bool $use_default
	 *
	 * }
	 *
	 * @return string
	 */
	function get_thumbnail_url( $args = array() ) {

		return $this->get_image_url( 'thumbnail', $args );

	}

	/**
	 * Get taxonomy image url (or a default image if $use_default === true ).
	 *
	 * @param string $size
	 * @param string|array $args {
	 *
	 *      @type bool $use_default
	 *
	 * }
	 *
	 * @return string
	 */
	function get_image_url( $size = 'full', $args = array() ) {

		$image_url = null;

		if ( $this->has_term() ) {

			$args = wp_parse_args( $args, array(
				'use_default' => false,
			));

			$url = $this->get_meta_value( 'image_url' );

			if ( $attachment_id = url_to_postid( $url )) {
				/*
				 * Lookup the correctly sized URL.
				 */
				$image_src = wp_get_attachment_image_src( $attachment_id, $size );
				if ( isset( $image_src[ 0 ] ) ) {
					$image_url = $image_src[ 0 ];
				}
			} else {
				/*
				 * Stored URL does not refer to attached media. No resizing capability.
				 */
				$image_url = $url;
			}

			/*
			 * If the image URL is empty and we want to use a default image do so
			 * otherwise return whatever was retrieved which could be a valid URL
			 * or it could be empty.
			 */

			if ( empty( $image_url ) && $args['use_default'] ) {

				$image_url = $this->default_image_url();

			}

		}

		return $image_url;

	}

	/**
	 * Get a value of an extended field.
	 *
	 * @param string $meta_name
	 * @param mixed|null $default
	 *
	 * @return string|null
	 */
	function get_meta_value( $meta_name, $default = null ) {

		do {

			$value = $default;

			if ( ! $this->has_term() ) {
				break;
			}

			$values = $this->get_meta_values();

			if ( ! isset( $values[ $meta_name ] ) ) {
				break;
			}

			$value = $values[ $meta_name ];

		} while ( false );

		return $value;

	}

	/**
	 * @param $meta_name
	 * @param $meta_value
	 * @param $sanitizer
	 *
	 * @return bool true if value is saved successfully, false otherwise
	 */
	function update_meta_value( $meta_name, $meta_value, $sanitizer ) {

		$values = $this->get_meta_values();

		$values[ $meta_name ] = KOAO::sanitize_meta( $meta_value, $sanitizer );

		return $this->update_meta_values( $values );

	}

	/**
	 * Get an associative array with the values of all extended fields.
	 *
	 * @return array
	 */
	function get_meta_values() {

		return get_option( $this->_meta_values_option_name() );

	}

	/**
	 * Get an associative array with the values of all extended fields.
	 *
	 * @param $values
	 * @return bool
	 */
	function update_meta_values( $values ) {

		return update_option( $this->_meta_values_option_name(), $values );

	}

	/**
	 * Provide the option name for simulating taxonomy meta values
	 *
	 * @return string
	 */
	private function _meta_values_option_name() {

		return '_koao_tax_meta[' . $this->term_id() .']';

	}

	/**
	 * Get URL to a default image of the taxonomy. If image with a taxonomy term does not exist, use a generic taxonomy icon.
	 *
	 * @return string
	 */
	function default_image_url() {

		/* note, there is no need to check if $this->has_term() */

		return $this->default_image_file_exists()
			? WPLib::get_asset_url( 'images/' . self::get_constant('TAXONOMY') . '/'. $this->term_slug() . '.svg', 'KOAO_Theme' )
			: KOAO::get_themeable_asset_url('generic-taxonomy-icon');
	}

	/**
	 * @return bool
	 */
	private function default_image_file_exists() {
		$theme = KOAO::theme();
		return $this->has_term()
		       ? call_user_func( 'file_exists', $theme->get_root_dir( "assets/images/{$this->taxonomy()}/{$this->term_slug()}.svg" ) )
		       : false;
	}

}
