<?php

/**
 * Class KOAO_Term_View_Base
 *
 * @mixin KOAO_Term_Model_Base
 *
 * @method KOAO_Term_Model_Base model()
 * @property KOAO_Term_Model_Base $model
 *
 * @method void the_image_url()
 * @method void the_thumbnail_url()
 */
class KOAO_Term_View_Base extends WPLib_Term_View_Base {

	/**
	 * @param string $size
	 * @param array $args {
	 *
	 *      @type bool $use_default
	 *
	 * }
	 * @return string
	 */
	function get_image_html( $size = 'full', $args = array() ) {

		return WPLib::get_img(
			$this->get_image_url( $size, $args ),
			array(
				'class' => 'taxonomy-icon',
				'title' => esc_attr( $this->term_name() )
			)
		);

	}

}

