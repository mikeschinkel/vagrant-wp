<?php

/**
 * Class KOAO_Term_Module_Base
 */
class KOAO_Term_Module_Base extends WPLib_Term_Module_Base {

	/**
	 *
	 */
	static function on_load() {

		//KOAO::register_helper( __CLASS__ );

	}

}
KOAO_Term_Module_Base::on_load();
