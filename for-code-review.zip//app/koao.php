<?php

/**
 * Class KOAO
 *
 * @mixin KOAO_Agency_Types
 * @mixin KOAO_Agencies
 * @mixin KOAO_Term_Module_Base
 * @mixin KOAO_Resources
 * @mixin KOAO_Exception_Requests
 * @mixin KOAO_Resource_Types
 * @mixin KOAO_Service_Types
 * @mixin KOAO_Work_Samples
 * @mixin KOAO_Departments
 * @mixin KOAO_People
 * @mixin KOAO_Elites
 * @mixin KOAO_Featured_Slides
 * @mixin KOAO_Site_Updates
 * @mixin KOAO_Expiring_Posts
 */
class KOAO extends WPLib_App_Base {

	const RECENT_COMMIT = 'ecab4dd';

	const PREFIX = 'KOAO_';
	const SHORT_PREFIX = 'koao_';

	const RESOURCES_MENU_SLUG = 'resources';

	static function on_load() {

		self::register_module( 'post-type-agency' );
		self::register_module( 'post-type-work-sample' );
		self::register_module( 'post-type-person' );
		self::register_module( 'taxonomy-department' );
		self::register_module( 'taxonomy-agency-type' );
		self::register_module( 'taxonomy-service-type' );
		self::register_module( 'post-type-resource' );
		self::register_module( 'role-elite' );
		self::register_module( 'taxonomy-resource-type' );
		self::register_module( 'post-type-featured-slide' );
		self::register_module( 'post-type-site-update' );
		self::register_module( 'post-type-exception-request' );
		self::register_module( 'component-uploader' );
		self::register_module( 'plugin-expiring-posts' );

	}

	/**
	 * @return KOAO_Theme
	 */
	static function theme() {

		return parent::theme();
	}

	/**
	 * @return array
	 */
	static function http_POST() {
		return is_array( $GLOBALS['_POST'] )
			? $GLOBALS['_POST']
			: array();
	}

	/**
	 * @param mixed $key
	 * @param bool $default
	 *
	 * @return mixed
	 */
	static function get_http_POST( $key, $default = null ) {
		$http_POST = self::http_POST();
		return isset( $http_POST[ $key ] )
			? $http_POST[ $key ]
			: $default;
	}

	/**
	 * @return array
	 */
	static function http_GET() {
		return is_array( $GLOBALS['_GET'] )
			? $GLOBALS['_GET']
			: array();
	}

	/**
	 * @param mixed $key
	 * @param bool $default
	 *
	 * @return mixed
	 */
	static function get_http_GET( $key, $default = null ) {
		$http_GET = self::http_GET();
		return isset( $http_GET[ $key ] )
			? $http_GET[ $key ]
			: $default;
	}

	/**
	 * Writes post meta ensuring the meta key has a leading underscore and the value is sanitized.
	 *
	 * @param int $post_id
	 * @param string $group_name
	 * @param string[] $fields
	 */
	static function update_post_meta_from_POST( $post_id, $group_name, $fields = array() ) {

		$group = static::get_http_POST( $group_name, false );

		/*
		 * NOTE: this function can be run when a form is submitted from the frontend.
		 */
		if ( $group && ( is_admin() || self::doing_ajax() ) && ! self::doing_xmlrpc() && ! self::doing_cron() ) {

			foreach ( $fields as $field_name => $sanitizer ) {

				if ( isset( $group[ $field_name ] ) ) {

					static::update_post_meta( $post_id, $field_name, $group[ $field_name ], $sanitizer );

				} else {

					static::delete_post_meta( $post_id, $field_name );

				}

			}
		}

	}

	/**
	 * Updates post meta but ensures that the meta key has a leading underscore.
	 *
	 * @param int $post_id
	 * @param string $field_name
	 * @param mixed $value
	 * @param string $sanitizer
	 *
	 * @return bool true if succeeded, false otherwise
	 */
	static function update_post_meta( $post_id, $field_name, $value = null, $sanitizer = 'text' ) {

		return update_post_meta(
			$post_id,
			static::_get_raw_meta_fieldname( $field_name ),
			self::sanitize_meta( $value, $sanitizer )
		);

	}

	const META_KEY_KEY = 'meta_key';
	const META_VALUE_KEY = 'meta_value';
	const TAX_QUERY_KEY = 'tax_query';
	const META_QUERY_KEY = 'meta_query';

	/**
	 * Can be used to sanitize post meta values as well as extended fields of terms.
	 *
	 * @param $value
	 * @param $sanitizer
	 *
	 * @return int|mixed|string
	 */
	static function sanitize_meta( $value, $sanitizer ) {

		switch ( $sanitizer ) {
			case 'raw':
				break;

			case 'bool':
			case 'boolean':
				$value = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
				break;

			case 'url':
				$value = esc_url_raw( $value );
				break;

			case 'email':
				$value = sanitize_email( $value );
				break;

			case 'int':
			case 'integer':
				$value = intval( $value );
				break;

			case 'embed':

				$value = wp_kses( $value, array(

					'iframe' => array(
						'width'           => true,
						'height'          => true,
						'src'             => true,
						'frameborder'     => true,
						'allowfullscreen' => true,
					),
					'audio'  => array(
						'autoplay' => true,
						'controls' => true,
						'loop'     => true,
						'muted'    => true,
						'preload'  => true,
						'src'      => true,
					),
					'video'  => array(
						'autoplay' => true,
						'controls' => true,
						'height'   => true,
						'loop'     => true,
						'muted'    => true,
						'poster'   => true,
						'preload'  => true,
						'src'      => true,
						'width'    => true,
					),

				) );

				break;

			case 'html':
				$value = wp_kses_post( $value );
				break;

			case 'text':
			default:

				$value = sanitize_text_field( $value );

		}

		return $value;
	}

	/**
	 * Deletes post meta but ensures that the meta key has a leading underscore.
	 *
	 * @param $post_id
	 * @param $field_name
	 */
	static function delete_post_meta( $post_id, $field_name ) {

		delete_post_meta( $post_id, static::_get_raw_meta_fieldname( $field_name ) );

	}

	/**
	 * @param string $form_name
	 * @param array $fields
	 * @param array $args (
	 *
	 * @type $entry WPLib_Post_Base
	 * @type $is_readonly bool whether to make controls read-only/disabled
	 * @type $use_query_args bool whether to take values from $_GET
	 * )
	 *
	 * @return string
	 */
	static function get_form_contents( $form_name, $fields, $args = array() ) {

		$args = wp_parse_args( $args, array(
			'entry'              => null,
			'is_readonly'        => false,
			'passed_values'      => false,
			'is_fully_sanitized' => false
		));

		$items = array();

		$readonly_html = $args[ 'is_readonly' ] ? ' readonly="readonly" ' : '';
		$disabled_html = $args[ 'is_readonly' ] ? ' disabled="disabled" ' : '';

		/**
		 * @var $entry WPLib_Post_Base
		 */
		$entry = null;
		if ( $args[ 'entry' ] && is_subclass_of( $args[ 'entry' ], 'WPLib_Post_Base' ) ) {
			$entry = $args[ 'entry' ];
		}

		foreach ( $fields as $field_name => $field ) :

			$value = null;

			if ( $field['type'] !== 'section' && $entry && $entry->has_post() ) {

				$value = $entry->$field_name();

			} elseif ( !empty( $args['passed_values'] ) && isset( $args['passed_values'][ $field_name ] ) && $args['passed_values'][ $field_name ] ) {

				$value = $args['is_fully_sanitized']
					   ? $args['passed_values'][ $field_name ]
					   : KOAO::sanitize_meta( $args['passed_values'][ $field_name ], $field['sanitizer'] );
			}

			$control_id = sanitize_title( $form_name . '_' . $field_name );

			switch ( $field[ 'type' ] ) :

				case 'section':
					$items[ $field_name ] = sprintf(
						'<legend class="%s">%s</legend>',
						$field_name,
						$field[ 'label' ]
					);
					break;

				case 'hidden':
					$items[ $field_name ] = sprintf(
						'<input name="%s[%s]" value="%s" type="hidden">',
						$form_name,
						$field_name,
						esc_attr( $value )
					);
					break;

				case 'text':
				case 'email':
				case 'tel':

					$esc_value = esc_attr( $value );
					$esc_label = esc_attr( $field[ 'label' ] );

					$items[ $field_name ] =
						"<label class='field {$field_name} {$field['type']}' for='{$control_id}' title='{$esc_label}'>".
							"<span class='label-text'>{$esc_label}</span>" .
							"<input name='{$form_name}[{$field_name}]' value='{$esc_value}'
									id='{$control_id}' type='{$field['type']}'
								    placeholder='{$esc_label}' {$readonly_html} >".
						"</label>";

					break;

				case 'radio':
					$inputs = '';

					if ( isset( $field[ 'options' ] ) ) {
						foreach ( $field[ 'options' ] as $key => $label ) {
							$inputs .= sprintf(
								'<label class="%s-%s radio-item">' .
								'<input type="radio" name="%s[%s]" value="%s" %s %s>' .
								'<span>%s</span>' .
								'</label>',
								esc_attr( $field_name ),
								esc_attr( $key ),
								$form_name,
								$field_name,
								esc_attr( $key ),
								checked( $key, $value, false ),
								$readonly_html,
								$label
							);
						}
					}

					$items[ $field_name ] = sprintf(
						'<label class="field %s radio">' .
						'<span class="label-text">%s</span>' .
						'%s' .
						'</label>',
						$field_name,
						$field[ 'label' ],
						$inputs
					);
					break;

				case 'select':
					$options = '';

					if ( isset( $field[ 'options' ] ) ) {
						foreach ( $field[ 'options' ] as $key => $label ) {
							$options .= sprintf(
								'<option value="%s" %s>%s</option>',
								esc_attr( $key ),
								selected( $key, $value, false ),
								$label
							);
						}
					}

					$items[ $field_name ] = sprintf(
						'<label class="field %s select">' .
						'<span class="label-text">' .
						'%s' .
						'</span>' .
						'<select name="%s[%s]" %s>%s</select>' .
						'</label>',
						$field_name,
						$field[ 'label' ],
						$form_name,
						$field_name,
						$readonly_html,
						$options
					);
					break;

				case 'editor':
					$items[ $field_name ] = sprintf(
						'<label class="field %s editor">' .
						'<span class="label-text">%s</span>' .
						'<textarea type="%s" name="%s[%s]" %s>%s</textarea>' .
						'</label>',
						$field_name,
						$field[ 'label' ],
						$field[ 'type' ],
						$form_name,
						$field_name,
						$readonly_html,
						esc_textarea( $value )
					);
					break;

				case 'media':
					$items[ $field_name ] = sprintf(
						'<div class="field %s media"><button class="button primary jq-attach" %s>%s</button>'.
						'<input id="%s" type="hidden" name="%s[%s]" value="%d"></div>',
						$field_name,
						$disabled_html,
						esc_attr( $field[ 'label' ] ),
						$control_id,
						$form_name,
						$field_name,
						esc_attr( $value )
					);
					break;

				case 'custom':
					if ( isset( $field['renderer'] ) && is_callable( $field['renderer'] ) ) {
						ob_start();

						$field['renderer'](
							$field,
							$value,
							array(
								'name'        => "{$form_name}[{$field_name}]",
								'control_id'  => $control_id,
								'is_readonly' => $args[ 'is_readonly' ]
							)
						);

						$items[ $field_name ] = ob_get_clean();
					}
					break;
			endswitch;
		endforeach;

		$items = apply_filters( 'koao_form_items', $items, $form_name );

		$html = "\n<div class=\"koao-form-fields $form_name\">";

		$is_section_open = false;
		foreach ( $items as $field_name => $item ) {
			if ( 'section' === $fields[ $field_name ][ 'type' ] ) {
				$html .= $is_section_open ? '</fieldset><fieldset>' : '<fieldset>';
				$is_section_open = true;
			}
			$html .= $item;
		}
		$html .= $is_section_open ? '</fieldset>' : '';

		$html .= '</div>';

		return $html;
	}

	/**
	 * @param array $fields field definitions
	 *
	 * @return array
	 */
	static function get_form_sanitizers( $fields ) {

		$sanitizers = array();
		foreach ( $fields as $field_name => $field ) {
			if ( ! empty( $field[ 'sanitizer' ] ) ) {
				$sanitizers[ $field_name ] = $field[ 'sanitizer' ];
			}
		}

		return $sanitizers;
	}

	/**
	 * @param int $agency_type_id
	 * @param int $agency_id
	 *
	 * @future KOAO should not "own" this knowledge.  This should be
	 *         instance properties of both agency_type and agency.
	 *
	 *
	 * @return string
	 */
	static function get_roster_file_url( $agency_type_id, $agency_id = null ) {

		$url = home_url();
		if ( absint( $agency_type_id ) > 0 ) {
			$args =	array(
				'roster'  => absint( $agency_id ) ? 'agency': 'agencies',
				'service' => absint( $agency_type_id )
			);
			if ( absint( $agency_id ) ) {
				$args['agency'] = $agency_id;
			}

			$url = add_query_arg( $args, $url );
		}
		return esc_url( $url );

	}

	/**
	 * @todo We don't need more specificly named get_asset_url() function.
	 *       Let's create a new KOAO::get_image_url().  If filename has no extension then it is a registered image.
	 *       Obviously we also needed KOAO::register_asset_file() and KOAO::register_image_file().
	 *       first arg is filename, 2nd is (optional) lookup key which defaults to basename() minus file extension.
	 *       Later we'll roll this into WPLib::get_image_url(), WPLib::register_asset_file() and WPLib::register_image_file() etc.
	 *
	 * @param string $name
	 *
	 * @return string
	 */
	static function get_themeable_asset_url( $name ){

		static $_themeable_assets;

		if ( is_null( $_themeable_assets ) ) {

			$images_url = WPLib::get_asset_url('/images/', 'KOAO_Theme');

			$defaults = array(
				'site-logo'              => "{$images_url}logo-coke.svg",

				'agencies-header'        => "{$images_url}header-agencies.jpg",
				'resources-header'       => "{$images_url}header-resources.jpg",
				'about-us-header'        => "{$images_url}header-about-us.jpg",
				'generic-header'         => "{$images_url}header-generic.jpg",

				'person-icon'            => "{$images_url}icon-person.svg",
				'agency-icon'            => "{$images_url}icon-agency.svg",

				'generic-file-type-icon' => "{$images_url}icon-file-type-generic.svg",
				'csv-file-type-icon'     => "{$images_url}icon-file-type-csv.svg",
				'pdf-file-type-icon'     => "{$images_url}icon-file-type-pdf.svg",
				'doc-file-type-icon'     => "{$images_url}icon-file-type-doc.svg",
				'ppt-file-type-icon'     => "{$images_url}icon-file-type-ppt.svg",
				'xls-file-type-icon'     => "{$images_url}icon-file-type-xls.svg",

				'document-resource-type-icon' => "{$images_url}icon-resource-type-document.svg",
				'link-resource-type-icon'     => "{$images_url}icon-resource-type-link.svg",
				'form-resource-type-icon'     => "{$images_url}icon-resource-type-form.svg",

				'generic-taxonomy-icon'       => "{$images_url}icon-taxonomy-generic.png",
			);

			$_themeable_assets = apply_filters('koao_themeable_assets', $defaults );
		}

		return !empty( $_themeable_assets[ $name ] )
			? esc_url_raw( $_themeable_assets[ $name ] )
			: '';

	}

	/**
	 * Dispenses a reusable Term based on the $term_id.
	 *
	 * @param int|object $term
	 * @param string $taxonomy
	 *
	 * @return KOAO_Term_Base
	 */
	static function dispense_term_item( $term, $taxonomy = null ) {

		static $terms;

		do {

			if ( is_numeric( $term ) ) {
				$term_id = $term;
				$term = get_term( $term, $taxonomy );
				break;
			}

			if ( $term instanceof WP_Term ) {
				$term_id = $term->term_id;
				break;
			}

			if ( is_object( $term ) && isset( $term->term_id ) ) {
				/*
				 * Note, this is needed, because some WP events pass in a term object
				 * that is not a WP_Term object, e.g. edit_form_fields hook.
				 */
				$term_id = $term->term_id;
				break;
			}

			if ( $term instanceof WPLib_Term_Base ) {
				$term_id = $term->term_id();
				$terms[ $term_id ] = $term;
			}

			if ( WPLib::is_development() ) {

				$err_msg = __( 'Value for term passed to %s() does not represent a term.', 'koao-theme' );
				WPLib::trigger_error( $err_msg, __METHOD__ );

				$term_id = 0;

			}

		} while ( false );

		if ( ! isset( $terms ) ) {

			$terms = array();

		}

		if ( empty( $terms[ $term_id ] ) ) {

			$terms[ $term_id ] = WPLib_Terms::make_new_item( $term, "taxonomy={$taxonomy}" );

		}

		return $terms[ $term_id ];

	}

}

KOAO::on_load();
