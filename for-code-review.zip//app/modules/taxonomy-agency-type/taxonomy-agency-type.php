<?php

/**
 * Class KOAO_Agency_Types
 */
class KOAO_Agency_Types extends KOAO_Term_Module_Base {

	const TAXONOMY       = 'koao-agency-type';
	const INSTANCE_CLASS = 'KOAO_Agency_Type';

	static function on_load() {

		/**
		 * Add this class as a helper to KOAO
		 */
		KOAO::register_helper( __CLASS__ );

		$labels = self::register_taxonomy_labels( array(
			'name'          => _x( 'Agency Types', 'taxonomy general name', 'koao-theme' ),
			'singular_name' => _x( 'Agency Type', 'taxonomy singular name', 'koao-theme' ),
		));

		self::register_taxonomy( KOAO_Agency::POST_TYPE, array(
			'labels'       => $labels,
			'public'       => true,
			'hierarchical' => true,
			'rewrite'      => array(
				'slug'       => 'agency-type',
				'with_front' => false,
			),
			'show_admin_column' => true,
			'koao_uploader' => true,
		) );

		/* Allow HTML */
		remove_filter( 'pre_term_description', 'wp_filter_kses' );
		//remove_filter( 'term_description',     'wp_kses_data' );

		/* Queue the render actions in admin_init. */
		self::add_class_action( 'admin_init' );

		/*
		 * Save custom fields when creating/editing a term.
		 */
		self::add_class_action( 'create_term' );
		self::add_class_action( 'edit_term' );
		self::add_class_filter( 'upload_mimes' );

	}

	/**
	 * @param $mimes
	 *
	 * @return mixed
	 * @see https://css-tricks.com/snippets/wordpress/allow-svg-through-wordpress-media-uploader/
	 *
	 */
	function _upload_mimes( $mimes ) {

	  $mimes['svg'] = 'image/svg+xml';
	  return $mimes;

	}

	/**
	 * @return KOAO_Agency_Type[]
	 */
	static function agency_types_list() {
		return self::get_agency_types_list( array() );
	}

	/**
	 * Get the list of agency types (including those that are not assigned to any agencies yet).
	 *
	 * @param array|string|WPLib_Query $query
	 * @param array $args
	 * @return KOAO_Agency_Type[]
	 */
	static function get_agency_types_list( $query, $args = array() ) {

		$query = wp_parse_args( $query, array( 'hide_empty' => 0 ));

		return self::get_list( $query, $args );

	}

	/**
	 * Add extended fields to Add term and Edit term page.
	 *
	 * @return  void
	 */
	static function _admin_init() {

		$taxonomy = self::get_constant('TAXONOMY');

		add_action( "{$taxonomy}_add_form_fields",  array( __CLASS__, '_add_url_field' ), 3, 1 );
		add_action( "{$taxonomy}_edit_form_fields", array( __CLASS__, '_edit_url_field' ), 3, 2 );

		add_action( "{$taxonomy}_add_form_fields",  array( __CLASS__, '_add_description_field' ), 2, 1 );
		add_action( "{$taxonomy}_edit_form_fields", array( __CLASS__, '_edit_description_field' ), 2, 2 );

		add_action( "{$taxonomy}_add_form_fields",  array( __CLASS__, '_add_richtext_field' ), 4, 1 );
		add_action( "{$taxonomy}_edit_form_fields", array( __CLASS__, '_edit_richtext_field' ), 4, 2 );

	}

	/**
	 * Add URL field in Add Term form.
	 */
	static function _add_url_field( $taxonomy ) {
		?>

		<div class="form-field">
			<label for="info_url"><?php _e( 'More Info URL', 'koao-theme' ); ?>
				<input type="text" name="info_url" id="info_url" value=""><br>
		</label>
		</div><?php
	}

	/**
	 * Add URL field in Edit term form.
	 *
	 * @param object $taxonomy
	 */
	static function _edit_url_field( $term, $taxonomy ) {


		$agency_type = KOAO::dispense_term_item( $term, self::TAXONOMY );

		?>

		<tr class="form-field">
		<th scope="row" valign="top">
			<label for="info_url"> <?php esc_html_e( 'More Info URL', 'koao-theme' ); ?></label>
		</th>
		<td>
			<input type="text" name="info_url" id="info_url" value="<?php $agency_type->the_more_info_url(); ?>">
		</td>
		</tr><?php

	}

	/**
	 * Extend term description editor with tinyMCE on the Add Term page.
	 */
	static function _add_description_field( $taxonomy ) {

		$settings = array(
			'quicktags'     => array( 'buttons' => 'em,strong,link' ),
			'textarea_name' => 'description',
			'tinymce'       => true,
			'editor_css'    => '<style>#wp-html-tag-description-editor-container .wp-editor-area{ height:150px; }</style>'
		);

		?>
		<div class="form-field term-description-wrap">
			<label for="tag-description"><?php esc_html_e( _x( 'Description', 'Taxonomy Description', 'koao-theme' ) ); ?></label>
			<?php wp_editor( '', 'html-tag-description', $settings ); ?>
			<p class="description"><?php esc_html_e( '', 'koao-theme' ); ?></p>
			<script type="text/javascript">
				// Remove the non-html field
				jQuery('textarea#tag-description').closest('.form-field').remove();

				jQuery(function () {
					// Trigger save
					jQuery('#addtag').on('mousedown', '#submit', function () {
						tinyMCE.triggerSave();
					});
				});

			</script>
		</div>
		<?php
	}


	/**
	 * Add a rich text field to the Add Term form.
	 */
	static function _add_richtext_field( $taxonomy ) {

		$settings = array(
			'quicktags'     => array( 'buttons' => 'em,strong,link' ),
			'textarea_name' => 'richtext',
			'tinymce'       => true,
			'editor_css'    => '<style>#wp-html-tag-richtext-editor-container .wp-editor-area{ height:150px; }</style>'
		);

		?>
		<div>
			<label for="tag-richtext"><?php _ex( 'Additional Details', 'Taxonomy meta field', 'koao-theme' ); ?></label>
			<?php wp_editor( '', 'html-tag-richtext', $settings ); ?>
			<p class="richtext"><?php esc_html_e( '', 'koao-theme' ); ?></p>
			<script type="text/javascript">
				// Remove the non-html field
				//jQuery( 'textarea#tag-richtext' ).closest( '.form-field' ).remove();

				jQuery(function () {
					// Trigger save
					jQuery('#addtag').on('mousedown', '#submit', function () {
						tinyMCE.triggerSave();
					});
				});

			</script>
		</div>
		<?php
	}

	/**
	 * Extend description editor with tinyMCE on Edit Term form.
	 *
	 * @param WP_Term $tag
	 */
	static function _edit_description_field( $tag, $taxonomy ) {

		$settings = array(
			'quicktags'     => array( 'buttons' => 'em,strong,link' ),
			'textarea_name' => 'description',
			'tinymce'       => true,
			'editor_css'    => '<style>#wp-html-description-editor-container .wp-editor-area{ height:250px; }</style>'
		);

		?>
		<tr>
			<th scope="row" valign="top">
				<label for="description"><?php esc_html_e( _x( 'Description', 'Taxonomy Description', 'koao-theme' ) ); ?></label>
			</th>
			<td><?php wp_editor( htmlspecialchars_decode( $tag->description ), 'html-description', $settings ); ?>
				<span
					class="description"><?php esc_html_e( '', 'koao-theme' ); ?></span>
			</td>
			<script type="text/javascript">
				// Remove the non-html field
				jQuery('textarea#description').closest('.form-field').remove();
			</script>
		</tr>
		<?php
	}

	/**
	 * Add a rich text field on Edit Term form.
	 *
	 * @param WP_Term $term
	 */
	static function _edit_richtext_field( $term ) {

		$agency_type = KOAO::dispense_term_item( $term, self::TAXONOMY );

		$settings = array(
			'quicktags'     => array( 'buttons' => 'em,strong,link' ),
			'textarea_name' => 'richtext',
			'tinymce'       => true,
			'editor_css'    => '<style>#wp-html-richtext-editor-container .wp-editor-area{ height:250px; }</style>'
		);

		$richtext = $agency_type->get_meta_value( 'richtext' );

		?>
		<tr>
			<th scope="row" valign="top">
				<label for="richtext"><?php esc_html_e( _x( 'Additional Details', 'Taxonomy meta field', 'koao-theme' )); ?></label>
			</th>
			<td><?php wp_editor( htmlspecialchars_decode( $richtext ), 'html-richtext', $settings ); ?>
				<span
					class="richtext"><?php esc_html_e( '', 'koao-theme' ); ?></span>
			</td>
		</tr>
		<?php

	}

	/**
	 * On Edit Term, save extended meta fields.
	 *
	 * @param $term_id
	 */
	static function _edit_term( $term_id ) {

		self::_update_extended_fields_from_POST( $term_id );
	}

	/**
	 * On Crate Term, save extended meta fields.
	 *
	 * @param $term_id
	 */
	static function _create_term( $term_id ) {

		self::_update_extended_fields_from_POST( $term_id );

	}

	protected static function _update_extended_fields_from_POST( $term_id ) {

		$agency_type = KOAO::dispense_term_item( $term_id, self::TAXONOMY );

		if ( $info_url = KOAO::get_http_POST( 'info_url', false ) ) {
			$agency_type->update_meta_value( 'info_url', esc_url_raw( $info_url ), 'url' );
		}

		if ( $richtext = KOAO::get_http_POST( 'richtext', false ) ) {
			$agency_type->update_meta_value( 'richtext', wp_kses_post( $richtext ), 'html' );
		}

	}
}

KOAO_Agency_Types::on_load();
