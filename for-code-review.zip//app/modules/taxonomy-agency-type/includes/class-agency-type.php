<?php

/**
 * Class KOAO_Agency_Type
 *
 * @mixin KOAO_Agency_Type_View
 * @mixin KOAO_Agency_Type_Model
 *
 * @property KOAO_Agency_Type_View $view
 * @property KOAO_Agency_Type_Model $model
 *
 */
class KOAO_Agency_Type extends KOAO_Term_Base {

	const TAXONOMY = KOAO_Agency_Types::TAXONOMY;
	const VAR_NAME = 'agency_type';

}
