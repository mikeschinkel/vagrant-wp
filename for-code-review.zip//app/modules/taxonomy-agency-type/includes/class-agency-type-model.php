<?php

/**
 * Class KOAO_Agency_Type_Model
 *
 * @mixin KOAO_Agency_Type_View
 *
 * @method KOAO_Agency_Type_View view()
 */
class KOAO_Agency_Type_Model extends KOAO_Term_Model_Base {

	/**
	 * @return string
	 */
	function more_info_url() {

		return $this->get_meta_value( 'info_url', '' );

	}
	/**
	 * @return string
	 */
	function details() {

		return $this->get_meta_value( 'richtext', '' );

	}

	/**
	 * @return string|void
	 */
	function roster_file_url() {

		return KOAO::get_roster_file_url( $this->term_id() );

	}

	/**
	 * @return bool
	 */
	function has_agencies() {

	 	return !empty( $this->agency_ids() );

	}

	/**
	 * @return int[]
	 */
	function agency_ids() {

		return get_objects_in_term(
			$this->term_id(),
			KOAO_Agency_Type::TAXONOMY
		);

	}

	/**
	 * Return list of KOAO_Agency object for this taxonomy term.
	 *
	 * @return KOAO_Agency[]
	 */
	function agency_list() {

	 	return KOAO::get_agency_list( array(
            'post__in' => $this->agency_ids()
        ));

	}

}
