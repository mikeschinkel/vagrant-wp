<?php

/**
 * Class KOAO_Agency_Type_View
 *
 * @mixin KOAO_Agency_Type_Model
 * @property KOAO_Agency_Type $controller
 *
 * @method KOAO_Agency_Type_Model model()
 *
 * @method void the_term_description_html()
 * @method void the_more_info_url()
 * @method void the_details_html()
 * @method void the_permalink_url()
 * @method void the_term_name_html()
 * @method void the_learn_more_link()
 * @method void the_image_url( $size = 'full', $args = array() )
 * @method void the_thumbnail_url( $args = array() )
 * @method void the_image_html( $size = 'full', $args = array() )
 */
class KOAO_Agency_Type_View extends KOAO_Term_View_Base {

	function the_roster_file_url() {
		echo $this->get_roster_file_url();
	}

	function get_roster_file_url() {

		/* this url is already url-escaped */
		return $this->roster_file_url();

	}

	/**
	 * @return string
	 */
	function get_term_name_attr() {

		return esc_attr( $this->term_name() );
	}

	/**
	 * @param array $args {
	 *
	 *      @type string $class
	 *      @type string $link_text
	 *
	 * }
	 * @return string
	 */
	function get_learn_more_link( $args = array() ) {

		/**
		 * The text-right class is representational, but it can be replaced/modified via args.
		 */
		$args = wp_parse_args( $args, array(
			'class'     => 'text-right',
			'link_text' => __( 'Learn More', 'koao-theme' )
			               . ' <i class="fa fa-caret-right"></i>',
		));

		return WPLib::get_link( $this->more_info_url(), $args['link_text'], $args );

	}


	function get_term_name_html() {
		return esc_html( $this->term_name());
	}

}