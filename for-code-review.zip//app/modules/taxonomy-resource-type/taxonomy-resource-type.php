<?php

/**
 * Class KOAO_Resource_Types
 */
class KOAO_Resource_Types extends KOAO_Term_Module_Base {

	const TAXONOMY = 'koao-resource-type';
	const INSTANCE_CLASS = 'KOAO_Resource_Type';

	static function on_load() {

		/**
		 * Add this class as a helper to KOAO
		 */
		KOAO::register_helper( __CLASS__ );

		$labels = self::register_taxonomy_labels( array(
			'name'          => _x( 'Resource Types', 'taxonomy general name', 'koao-theme' ),
			'singular_name' => _x( 'Resource Type', 'taxonomy singular name', 'koao-theme' ),
		));

		self::register_taxonomy(
			array(
				KOAO_Resource::POST_TYPE,
			),
			array(
				'labels'       => $labels,
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'resources',
				'show_admin_column' => true,
				'hierarchical'      => true,
				'rewrite'           => array(
					'slug'       => 'resource-types',
					'with_front' => false,
				),
				'koao_uploader' => true,
			)
		);


		/*
		 * Add some CSS
		 */
		self::add_class_action('admin_head');

		/*
		 * Add Resource Types admin page under Resources menu section.
		 */
		self::add_class_action('admin_menu');

		/*
		 * Make sure Resources top level menu is highlighted when looking at Resource Types page
		 */
		self::add_class_action('parent_file');

		/*
		 * Save custom fields when creating/editing a term.
		 */
		self::add_class_action( 'create_term' );

		self::add_class_action( 'edit_term' );

		/**
		 * Add extra field to admin list and Add Term/Edit Term forms.
		 */
		self::add_class_action( 'admin_init' );

	}

	/**
	 * Add extended fields to Add term and Edit term page.
	 *
	 * @return  void
	 */
	static function _admin_init() {

		if (( $taxonomy = self::get_constant('TAXONOMY')) === WPLib::current_screen()->taxonomy ) {

			/**
			 * Add fields to Add Term / Edit Term forms.
			 */
			add_action( "{$taxonomy}_add_form_fields", array( __CLASS__, '_add_form_fields' ), 1, 1 );
			add_action( "{$taxonomy}_edit_form_fields", array( __CLASS__, '_edit_form_fields' ), 1, 2 );

			/*
			 * Add columns to admin list.
			 */
			add_filter( "manage_edit-{$taxonomy}_columns", array( __CLASS__, '_manage_edit_columns' ) );
			add_filter( "manage_{$taxonomy}_custom_column", array( __CLASS__, '_manage_custom_column' ), 10, 3 );
		}

	}

	/**
	 * Get unfiltered list of resource type instances.
	 *
	 * @param array|string|WPLib_Query $query
	 * @param array $args
	 * @return KOAO_Resource_Type[]
	 */
	static function get_resource_type_list( $query = array(), $args = array() ) {

		return self::get_list( $query, $args );

	}

	/*
	 * Make sure Resources top level menu is highlighted when looking at Resource Types page
	 */
	static function _parent_file( $parent_file ) {
		global $current_screen; //, $submenu_file;

		if ( self::TAXONOMY === $current_screen->taxonomy ) {

			// @todo Code Sniffer does not allow this, therefore -- comment out
			//if ( 'edit-tags.php' === $pagenow ) {
			//	$submenu_file = 'edit-tags.php?taxonomy=' . self::TAXONOMY;
			//}

			$parent_file = KOAO::RESOURCES_MENU_SLUG;
		}

		return $parent_file;
	}

	/*
	 * Add Resource Types admin page under Resources menu section.
	 */
	static function _admin_menu() {

		add_submenu_page(
			KOAO::RESOURCES_MENU_SLUG,  // <--- @todo Probably need new type of module: Admin Menu module w/KOAO_Resources_Menu::MENU_SLUG
			__('Resource Types', 'koao-theme'),
			__('Resource Types', 'koao-theme'),
			'edit_posts',
			'edit-tags.php?taxonomy=' . self::TAXONOMY,
			null
		);
	}

	/**
	 * Add some CSS.
	 */
	static function _admin_head() { ?>

		<style type="text/css" media="screen">
			p.desc {
				display: inline-block;
			}
			.widefat td.column-access {
				color: goldenrod;
			}
		</style> <?php
	}

	/**
	 * Add URL field in Add Term form.
	 */
	static function _add_form_fields( $taxonomy ) {

		if ( self::TAXONOMY === $taxonomy ) : ?>
		<div class="form-field">
		  <label for="koao_is_protected_term"><?php esc_html_e( 'Access Level', 'koao-theme' ); ?><br>
			<input type="checkbox" name="koao_is_protected_term" id="koao_is_protected_term" value="1" />
			<p class="desc"><?php esc_html_e('Make resources of this type available to Elite users only', 'koao-theme'); ?></p>
		  </label>
		</div>
		<?php endif;

	}

	/**
	 * Add URL field in Edit term form.
	 *
	 * @param $term WP_Term
	 * @param $taxonomy string
	 */
	static function _edit_form_fields( $term, $taxonomy ) {

		if ( self::TAXONOMY === $taxonomy ) :

		$resource_type = new KOAO_Resource_Type( $term ); ?>

		<tr class="form-field">
		<th scope="row" valign="top">
			<label for="info_url"> <?php esc_html_e( 'Access Level', 'koao-theme' ); ?></label>
		</th>
		<td>
			<input type="checkbox" name="koao_is_protected_term" id="koao_is_protected_term" value="1" <?php checked( $resource_type->is_protected(), true ); ?> />
			<p class="desc"><?php esc_html_e('Make resources of this type available to Elite users only', 'koao-theme'); ?></p>
		</td>
		</tr><?php

		endif;
	}

	/**
	 * @return KOAO_Resource_Type[]
	 */
	static function resource_types() {
		return self::get_resource_types( array() );
	}

	/**
	 * @param string|array $query
	 * @param array $args
	 *
	 * @return KOAO_Resource_Type[]
	 */
	static function get_resource_types( $query, $args = array() ) {

		$args = wp_parse_args( $args, array(
			'show_protected' => KOAO::current_user_can_read_protected_resources(),
			'protected_only' => false /* ignored when show_protected is false */
		));

		$term_objects = array();
		$terms = get_terms( self::get_constant('TAXONOMY'), $query );
		if ( $terms && is_array( $terms ) ) {

			$show_protected = $args[ 'show_protected' ];
			$protected_only = $args[ 'protected_only' ];
			foreach ( $terms as $term ) {
				$term_object = new KOAO_Resource_Type( $term );
				if ( $show_protected ) {
					if ( $protected_only && !$term_object->is_protected() ) {
						continue;
					}
					$term_objects[] = $term_object;
				} else {
					if ( ! $term_object->is_protected() ) {
						$term_objects[] = $term_object;
					}
				}
			}
		}

		return $term_objects;
	}

	/**
	 * Fires after a term has been updated, but before the term cache has been cleaned.
	 *
	 * @link https://developer.wordpress.org/reference/hooks/edit_term/
	 *
	 * @param $term_id int Term ID.
	 * @param $tt_id int Term taxonomy ID.
	 * @param $taxonomy string Taxonomy slug.
	 */
	static function _edit_term( $term_id, $tt_id, $taxonomy ) {

		if ( $taxonomy === self::TAXONOMY ) {
			self::_update_extra_fields_from_POST( $term_id );
		}
	}

	/**
	 * Fired immediately after a new term is created, before the term cache is cleaned.
	 *
	 * @link https://developer.wordpress.org/reference/hooks/create_term/
	 *
	 * @param $term_id int Term ID.
	 * @param $tt_id int Term taxonomy ID.
	 * @param $taxonomy string Taxonomy slug.
	 */
	static function _create_term( $term_id, $tt_id, $taxonomy ) {

		if ( $taxonomy === self::TAXONOMY ) {
			self::_update_extra_fields_from_POST( $term_id );
		}
	}

	/**
	 * @param $term_id
	 *
	 * @return bool true if successful, false otherwise
	 */
	static function _update_extra_fields_from_POST( $term_id ) {

		/**
		 * @var $resource_type KOAO_Resource_Type
		 */
		$resource_type = new KOAO_Resource_Type( $term_id );


		$is_protected = (bool) KOAO::get_http_POST( 'koao_is_protected_term', false );

		return $resource_type->update_protected_status( $is_protected );

	}

	/**
	 * Add Image column to Terms admin list.
	 *
	 * @access public
	 *
	 * @param mixed $columns
	 *
	 * @return array
	 */
	static function _manage_edit_columns( $columns ) {

		$new_columns = array();

		$new_columns['cb']      = $columns['cb'];
		$new_columns['name']    = $columns['name'];
		$new_columns['access']  = __( 'Access Level', 'koao-theme' );

		unset( $columns['cb'] );
		unset( $columns['name'] );

		return array_merge( $new_columns, $columns );
	}

	/**
	 * Render Thumbnail on terms admin list.
	 *
	 * @param mixed $row
	 * @param string $column_name
	 * @param int $term_id
	 *
	 * @return array
	 */
	static function _manage_custom_column( $row, $column_name, $term_id ) {

		if ( 'access' === $column_name ) {

			$term_item = new KOAO_Resource_Type( $term_id );

			echo $term_item->is_protected() ? _x('Elite', 'access level for resource type', 'koao-theme') : '';

		}
	}

}

KOAO_Resource_Types::on_load();
