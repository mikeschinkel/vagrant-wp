<?php

/**
 * Class KOAO_Resource_Type
 *
 * @mixin KOAO_Resource_Type_View
 * @mixin KOAO_Resource_Type_Model
 *
 * @property KOAO_Resource_Type_View $view
 * @property KOAO_Resource_Type_Model $model
 */
class KOAO_Resource_Type extends KOAO_Term_Base {

	const TAXONOMY = KOAO_Resource_Types::TAXONOMY;

}
