<?php

/**
 * Class KOAO_Resource_Type_View
 *
 * @mixin KOAO_Resource_Type_Model
 * @property KOAO_Resource_Type $controller
 *
 * @method KOAO_Resource_Type_Model model()
 * @method string the_term_slug_attr()
 * @method string the_term_name_html()
 *
 */
class KOAO_Resource_Type_View extends KOAO_Term_View_Base {

}
