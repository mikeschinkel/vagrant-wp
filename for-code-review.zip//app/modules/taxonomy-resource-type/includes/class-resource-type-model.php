<?php

/**
 * Class KOAO_Resource_Type_Model
 *
 * @mixin KOAO_Resource_Type_View
 *
 * @method KOAO_Resource_Type_View view()
 */
class KOAO_Resource_Type_Model extends KOAO_Term_Model_Base {

	function term_description() {
		return $this->has_term() ? $this->term()->description : '';
	}

	/**
	 * Is this type of resources available exclusively to Elite users?
	 *
	 * @return bool
	 */
	function is_protected() {
		return $this->get_meta_value( 'is_protected', false );
	}

	/**
	 * @param $is_protected bool
	 */
	function update_protected_status( $is_protected ) {

		return $this->update_meta_value( 'is_protected', $is_protected, 'bool');

	}

	/**
	 * @return bool
	 */
	function has_resources() {

	 	return !empty( $this->resource_ids() );

	}

	/**
	 * @return int[]
	 */
	function resource_ids() {

		return get_objects_in_term(
			$this->term_id(),
			KOAO_Resource_Type::TAXONOMY
		);

	}

	/**
	 * Return list of KOAO_Resource object for this taxonomy term.
	 *
	 * @return KOAO_Resource[]
	 */
	function resources_list() {

	 	return KOAO::get_resources_list( array(
            'post__in' => $this->resource_ids()
        ));

	}

}