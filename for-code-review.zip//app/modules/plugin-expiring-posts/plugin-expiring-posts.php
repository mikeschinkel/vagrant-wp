<?php
/**
 * Class KOAO_Expiring_Posts
 */
class KOAO_Expiring_Posts extends WPLib_Module_Base {

	const MODULE_NAME    = 'expiring-posts';
	const INSTANCE_CLASS = 'KOAO_Expiring_Posts';


	static function on_load() {

		/**
		 * @todo @saru We should probably not include the plugin inside the module as its canonical source
		 *       is not our repo. Instead we should probably only add the hooks IF the plugin is installed.
		 *       That means we add all the hooks in an 'init' hook and test to see if the plugin is available.
		 *       I am thinking that will be the patter we use for all modules that add support for or modify
		 *       and/or enhance the behaviour of a plugin.
		 *
		 * @todo Should this not also be limited to just
		 */
		if ( ! class_exists('EXP_Expiring_Posts') ) {
			$plugin_path = 'plugins/expiring-posts/';
			if ( ! defined( 'EXPIRING_POSTS_URL' ) ) {
				define( 'EXPIRING_POSTS_URL', self::get_root_url( $plugin_path ) );
			}
			include self::get_root_dir( "{$plugin_path}/expiring-posts.php" );
		}

		// make sure expired post meta field follows directly after publish field
		self::add_class_action( 'post_submitbox_misc_actions', 4 );

		// enqueue admin JS and CSS for styling and DOM Voodoo
		self::add_class_action( 'admin_enqueue_scripts', 9 );

		// Enqueue custom post status
		self::add_class_action( 'init', 9 );

		// Action from wp_transition_post_status
		self::add_class_action( 'expired_post', 9 );

		// Unschedule exp_expire_post_event for this post if it is deleted
		self::add_class_action( 'after_delete_post', 9 );

		// Event scheduled when an expiration date is set
		self::add_class_action( 'exp_expire_post_event', 9 );

		// Save expired posts meta
		self::add_class_action( 'save_post', 9 );

		// Update all posts view to show expired status
		self::add_class_action( 'display_post_states', 9 );
	}

	/**
	 * Return a numerically indexed array of post type slugs that are expiring.
	 *
	 * @return string[]
	 */
	static function expiring_post_types() {

		static $_expiring_post_types;

		if ( is_null( $_expiring_post_types ) ) {
			$defaults = array(
				/**
				 * @todo Rather than do this here, better to add a 'koao_can_expire' value to Register Post Type
				 *       and then gather the post types here. That way if we add a post type that we want to expire
				 *       we don't have to modify this module.
				 */
				KOAO_Site_Updates::POST_TYPE
			);
			/**
			 * @todo I think we should be very careful about adding filters before we need them.
			 *       When you add a filter you create another interface we have to explore to see where it is
			 *       being used before we can make a change. Why add that burden if we don't need the hook yet?
			 *       For custom apps for custom sites I do not see the need for hooks in 99% of cases. Do you?
			 *
			 * @todo Saru: also, you originally had 'koao_expiring_posts' which is semantically incorrect.
			 *       I searched and did not find any use of 'koao_expiring_posts' so I change it, but even so
			 *       I think we should remove it.
			 */
			$_expiring_post_types = apply_filters( 'koao_expiring_post_types', $defaults, __METHOD__ );
		}

		return $_expiring_post_types;

	}

	/**
	 * @param string $post_type
	 *
	 * @return bool|int
	 */
	static function is_expiring_post_type( $post_type ) {

		static $_pattern;

		if ( is_null( $_pattern ) ) {
			$_pattern = implode( '|', self::expiring_post_types() );
			$_pattern = "#^({$_pattern})$#";
		}

		return ! empty( $post_type )
			? (bool) preg_match( $_pattern, $post_type )
			: false;

	}

	/**
	 * @todo Saru: What do you think of using this instead?
	 *       _remove_method_hooks() could be a future WPLib helper method and
	 *       this one method is a lot more readable than a bunch of them
	 *       I am assuming we can remove them all during 'init' priority 0.
	 */
	static function _init_0() {

		if ( ! self::is_expiring_post_type( self::_get_current_post_type() ) ) {

			self::_remove_method_hooks( EXP_Expiring_Posts::instance(), array(
				'post_submitbox_misc_actions' => 'post_meta_box:5',
				'admin_enqueue_scripts'       => 'admin_scripts',
				'init'                        => 'expiring_post_status',
				'expired_post'                => 'expired_post_transition',
				'after_delete_post'           => 'unschedule_expired_post',
				'exp_expire_post_event'       => 'check_and_expire_scheduled_post',
				'save_post'                   => 'save_expiration_date',
				'display_post_states'         => 'add_expiry_post_states',
			));

		}

	}

	/**
	 * Remove the hooks implemented via methods for an object instance or class name.
	 *
	 * @todo This might make a good future WPLib helper.
	 * @param object|string $target Object instance or class name
	 * @param string[] $hooks Array of hooks and method names. To reference optional priority and param count:
	 *
	 *      'method_name'                         (priority==10, param_count==1)
	 *      'method_name:priority                (param_count==1)
	 *      'method_name:priority:param_count
	 */
	static function _remove_method_hooks( $target, $hooks ) {

		foreach( $hooks as $hook => $hook_info ) {

			if ( ! preg_match( '#^(.+)(:\d+(:\d+)?)?$#', $hook_info, $matches ) ) {
				continue;
			}

			$callable = array( $target, $matches[1] );

			switch (count( $matches ) ) {
				case 1:
					remove_action( $hook, $callable );
					continue;
				case 2:
					remove_action( $hook, $callable, intval( $matches[2] ) );
					continue;
				case 3:
					remove_action( $hook, $callable, intval( $matches[2] ), intval( $matches[3] ) );
					continue;

			}

		}

	}

	/**
	 * Grabs the current post type from the environment
	 *
	 * @return string
	 */
	private static function _get_current_post_type() {

		$screen = WPLib::current_screen();
		return $screen->post_type
			? $screen->post_type
			: filter_input( INPUT_GET, 'post_type' );

	}

	/************************************/
	/*** THE HARDCODED APPROACH BELOW ***/
	/************************************/

	// make sure expired post meta field follows directly after publish field
	static function _post_submitbox_misc_actions_4() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'post_submitbox_misc_actions', array( EXP_Expiring_Posts::instance(), 'post_meta_box' ), 5 );
		}
	}

	// enqueue admin JS and CSS for styling and DOM Voodoo
	static function _admin_enqueue_scripts_9() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'admin_enqueue_scripts', array( EXP_Expiring_Posts::instance(), 'admin_scripts' ), 10 );
		}
	}

	// Add custom post status
	static function _init_9() {
		if ( isset( $_GET['post_type']) && ! self::is_expiring_post_type( $_GET['post_type'] )) {
			remove_action( 'init', array( EXP_Expiring_Posts::instance(), 'expiring_post_status' ), 10 );
		}
	}

	// Action from wp_transition_post_status
	static function _expired_post_9() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'expired_post', array( EXP_Expiring_Posts::instance(), 'expired_post_transition' ), 10 );
		}
	}

	// Unschedule exp_expire_post_event for this post if it is deleted
	static function _after_delete_post_9() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'after_delete_post', array( EXP_Expiring_Posts::instance(), 'unschedule_expired_post' ), 10 );
		}
	}

	// Event scheduled when an expiration date is set
	static function _exp_expire_post_event_9() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'exp_expire_post_event', array( EXP_Expiring_Posts::instance(), 'check_and_expire_scheduled_post' ), 10 );
		}
	}

	// Save expired posts meta
	static function _save_post_9() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'save_post', array( EXP_Expiring_Posts::instance(), 'save_expiration_date' ), 10 );
		}
	}

	// Update all posts view to show expired status
	static function _display_post_states_9() {
		$screen = WPLib::current_screen();
		if ( ! self::is_expiring_post_type( $screen->post_type ) ) {
			remove_action( 'display_post_states', array( EXP_Expiring_Posts::instance(), 'add_expiry_post_states' ) );
		}
	}

}
KOAO_Expiring_Posts::on_load();
