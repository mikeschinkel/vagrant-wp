<?php

/**
 * Class WPLib_Users
 */
class KOAO_Elites extends WPLib_Subscribers {

	const ROLE = 'elite';

	static function _CAPABILITIES() {

		return array(

			'read_protected_resources',

			'download_roster_files'

		);
	}

	/**
	 * Run on WordPress's 'init' hook to register all the user types defined in classes that extend this class.
	 */
	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		self::add_class_action( 'init' );

	}

	static function _init() {

		self::register_role( __( 'Elite User', 'koao-theme' ) );

	}

	/**
	 * @return bool
	 */
	static function current_user_can_read_protected_resources() {

		return current_user_can( 'read_protected_resources' );

	}

	/**
	 * @return bool
	 */
	static function current_user_can_download_roster_files() {

		return current_user_can( 'download_roster_files' );

	}


}
KOAO_Elites::on_load();
