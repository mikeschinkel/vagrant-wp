<?php

/**
 * Class KOAO_Elite
 *
 * The user type of 'elite'
 */
class KOAO_Elite extends WPLib_User_Base {

	/**
	 * The user role slug
	 *
	 * @var string
	 */
	const ROLE = KOAO_Elites::ROLE;

}
