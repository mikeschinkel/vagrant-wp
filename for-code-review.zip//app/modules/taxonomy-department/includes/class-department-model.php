<?php

/**
 * Class KOAO_Department_Model
 *
 * @mixin KOAO_Department_View
 *
 * @method KOAO_Department_View view()
 */
class KOAO_Department_Model extends KOAO_Term_Model_Base {

	/**
	 * @param array|string|WPLib_Query $query
	 * @param array $args
	 *
	 * @return KOAO_Person[]
	 */
	function people_list( $query = array(), $args = array() ) {

		if ( ! $this->has_term() ) {
			return array();
		}

		$query = wp_parse_args( $query, array(
			KOAO::TAX_QUERY_KEY => array(
				array(
					'taxonomy' => KOAO_Department::TAXONOMY,
					'field'    => 'term_id',
					'terms'    => $this->term_id(),
				)
			)
		));

		return KOAO::get_persons_list( $query, $args );
	}

}
