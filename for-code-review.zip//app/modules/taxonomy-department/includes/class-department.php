<?php

/**
 * Class KOAO_Department
 *
 * @mixin KOAO_Department_View
 * @mixin KOAO_Department_Model
 *
 * @property KOAO_Department_View $view
 * @property KOAO_Department_Model $model
 *
 */
class KOAO_Department extends KOAO_Term_Base {

	const TAXONOMY = KOAO_Departments::TAXONOMY;

}
