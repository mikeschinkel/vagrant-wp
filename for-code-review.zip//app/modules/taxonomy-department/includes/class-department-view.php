<?php

/**
 * Class KOAO_Department_View
 *
 * @mixin KOAO_Department_Model
 * @property KOAO_Department $controller
 *
 * @method KOAO_Department_Model model()
 *
 * @method string the_term_slug_attr();
 * @method string the_term_description_html();
 * @method string the_term_name_html();
 * @method string the_permalink_url()
 * @method string the_image_html( $size = 'full' )
 */
class KOAO_Department_View extends KOAO_Term_View_Base {

}
