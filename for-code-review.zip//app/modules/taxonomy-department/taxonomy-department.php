<?php

/**
 * Class KOAO_Departments
 */
class KOAO_Departments extends KOAO_Term_Module_Base {

	const TAXONOMY       = 'koao-department';
	const INSTANCE_CLASS = 'KOAO_Department';


	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_taxonomy_labels( array(
			'name'          => _x( 'Departments', 'taxonomy general name',  'koao-theme' ),
			'singular_name' => _x( 'Department',  'taxonomy singular name', 'koao-theme' ),
		));

		self::register_taxonomy( KOAO_Person::POST_TYPE, array(
			'labels'       => $labels,
			'public'       => true,
			'hierarchical' => true,
			'rewrite'      => array(
				'slug'       => 'departments',
				'with_front' => false,
			),
			'show_admin_column' => true,
		) );

	}

	/**
	 * @return KOAO_Department[]
	 */
	static function departments_list() {

		return self::get_departments_list( array() );

	}

	/**
	 * Can be accessed via KOAO to fetch all departments.
	 *
	 * @param array|string|WPLib_Query $query
	 * @param array $args
	 * @return KOAO_Department[]
	 */
	static function get_departments_list( $query, $args = array() ) {

		return self::get_list( $query, $args );

	}

}

KOAO_Departments::on_load();
