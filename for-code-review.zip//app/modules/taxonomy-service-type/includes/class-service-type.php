<?php

/**
 * Class KOAO_Service_Type
 *
 * @mixin KOAO_Service_Type_View
 * @mixin KOAO_Service_Type_Model
 *
 * @property KOAO_Service_Type_View $view
 * @property KOAO_Service_Type_Model $model
 */
class KOAO_Service_Type extends KOAO_Term_Base {

	const TAXONOMY = KOAO_Service_Types::TAXONOMY;

}
