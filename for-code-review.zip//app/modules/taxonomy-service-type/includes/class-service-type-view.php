<?php

/**
 * Class KOAO_Service_Type_View
 *
 * @mixin KOAO_Service_Type_Model
 * @property KOAO_Service_Type $controller
 *
 * @method KOAO_Service_Type_Model model()
 *
 */
class KOAO_Service_Type_View extends WPLib_Term_View_Base {

}