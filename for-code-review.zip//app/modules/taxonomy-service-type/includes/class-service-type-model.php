<?php

/**
 * Class KOAO_Service_Type_Model
 *
 * @mixin KOAO_Service_Type_View
 *
 * @method KOAO_Service_Type_View view()
 */
class KOAO_Service_Type_Model extends WPLib_Term_Model_Base {


	/**
	 * @return bool
	 */
	function has_service_types() {

	 	return !empty( $this->service_type_ids() );

	}

	/**
	 * @return int[]
	 */
	function service_type_ids() {

		return get_objects_in_term(
			$this->term_id(),
			KOAO_Service_Type::TAXONOMY
		);

	}

	/**
	 * Return list of KOAO_Service_type object for this taxonomy term.
	 *
	 * @return KOAO_Service_type[[]
	 */
	function service_type_list() {

	 	return KOAO::get_service_type_list( array(
            'post__in' => $this->service_type_ids()
        ));

	}

}
