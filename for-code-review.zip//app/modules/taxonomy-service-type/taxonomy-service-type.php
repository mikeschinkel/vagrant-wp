<?php

/**
 * Class KOAO_Service_Types
 */
class KOAO_Service_Types extends WPLib_Term_Module_Base {

	const MODULE_NAME    = 'service_type';
	const TAXONOMY       = 'koao-service-type';
	const INSTANCE_CLASS = 'KOAO_Service_Type';

	/**
	 *
	 */
	static function on_load() {

		/**
		 * Add this class as a helper to WPLib
		 */
		self::register_helper( __CLASS__, 'WPLib' );

		self::register_taxonomy_labels(array(
			'name'          => _x( 'Service Types', 'taxonomy general name', 'koao-theme' ),
			'singular_name' => _x( 'Service Type', 'taxonomy singular name', 'koao-theme' ),
		));

		self::register_taxonomy( KOAO_Agency::POST_TYPE, array(
			'public'         => true,
			'hierarchical'   => false,
			'show_admin_column' => true,
			'rewrite'        => array(
				'slug'       => 'service-type',
				'with_front' => false,
			),
		));

	}


	/**
	 * @param array|string|WPLib_Query $query
	 * @param array $args
	 * @return KOAO_Service_Type[]
	 */
	static function get_service_type_list( $query = array(), $args = array() ) {

		return self::get_list( $query, $args );

	}

//	/**
//	 * @param array $args
//	 *
//	 * @return KOAO_Service_Type[]
//	 */
//	static function get_terms( $args = array() ) {
//
//		$term_objects = array();
//		$terms = get_terms( self::TAXONOMY, $args );
//		if ( $terms && is_array( $terms ) ) {
//			foreach ( $terms as $term ) {
//				$term_objects[] = new KOAO_Service_Type( $term );
//			}
//		}
//
//		return $term_objects;
//	}

}

KOAO_Service_Types::on_load();
