<fieldset class="koao-uploader">
	<div class="thumb inline-edit-col">
		<label>
			<span class="title"><img class="taxonomy-image" src="<?php echo KOAO::get_themeable_asset_url('generic-taxonomy-icon'); ?>" alt="<? esc_html_e( 'Thumbnail', 'koao-theme' ); ?>"></span>
			<span class="input-text-wrap">
				<input type="text" name="koao_image_url" value="">
			</span>
			<span class="input-text-wrap">
				<button class="image upload button"><?php esc_html_e( 'Upload/Add image', 'koao-theme' ); ?></button>
				<button class="image remove button"><?php esc_html_e( 'Remove image', 'koao-theme' ); ?></button>
			</span>
		</label>
	</div>
</fieldset>