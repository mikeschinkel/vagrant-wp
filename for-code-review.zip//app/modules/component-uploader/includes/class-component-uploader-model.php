<?php
/**
 * Class KOAO_Agency_Model
 *
 * @method KOAO_Agency_View view()
 * @property KOAO_Agency_View $view
 */

class KOAO_Uploader_Model extends WPLib_Model_Base {

}