<?php
/**
 * KOAO_Uploader
 *
 * @property KOAO_Uploader_Model $model
 * @property KOAO_Uploader_View $view
 *
 * @mixin KOAO_Uploader_Model
 * @mixin KOAO_Uploader_View
 *
 */
class KOAO_Uploader extends WPLib_Item_Base {

}