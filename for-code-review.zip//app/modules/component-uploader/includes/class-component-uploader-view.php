<?php
/**
 * Class KOAO_Uploader_View
 *
 * @mixin KOAO_Uploader
 *
 * @property KOAO_Uploader $item
 * @property KOAO_Uploader_Model $model
 */

class KOAO_Uploader_View extends WPLib_View_Base {

}