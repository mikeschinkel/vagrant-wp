<?php

/**
 * Class KOAO_Uploaders
 */
class KOAO_Uploaders extends WPLib_Module_Base {

	const INSTANCE_CLASS = 'KOAO_Uploader';

	/**
	 *
	 */
	static function on_load() {

		/*
		 * Hook actions to add extra fields and columns.
		 */
		self::add_class_action( 'admin_init' );

	}

	/**
	 * Add extended fields to Add term and Edit term page.
	 *
	 * @return  void
	 */
	static function _admin_init() {

		if ( self::screen_supports_uploader() ) {

			/*
			 * Enqueue uploader script
			 */
			/*
			 * Add CSS to style the image in category list
			 */
			self::add_class_action( 'admin_enqueue_scripts' );
			/*
			 * Add custom box for quick-edit
			 */
			self::add_class_action( 'quick_edit_custom_box' );
			/*
			 * Change caption for popup confirmation button.
			 */
			self::add_class_filter( 'attribute_escape' );

			$taxonomy = WPLib::current_screen()->taxonomy;

			add_action( "{$taxonomy}_add_form_fields",  array( __CLASS__, '_add_form_fields' ), 1, 1 );
			add_action( "{$taxonomy}_edit_form_fields", array( __CLASS__, '_edit_form_fields' ), 1, 2 );

			add_filter( "manage_edit-{$taxonomy}_columns",  array( __CLASS__, '_manage_edit_columns' ) );
			add_filter( "manage_{$taxonomy}_custom_column", array( __CLASS__, '_manage_custom_column' ), 10, 3 );

			/*
			 * Save image when submitting a new or existing term.
			 */
			self::add_class_action( 'edit_term' );
			self::add_class_action( 'create_term' );

		}

	}


	/**
	 * Add some CSS to tidy up the terms list.
	 */
	static function _admin_enqueue_scripts() {

		if ( self::screen_supports_uploader() ) {

			wp_enqueue_media();

			wp_enqueue_style(
				'koao-uploader-admin',
				WPLib::get_asset_url( 'css/uploader-admin.css', __CLASS__ )
			);

			wp_enqueue_script(
				'koao-uploader',
				WPLib::get_asset_url( 'js/uploader-admin.js', __CLASS__ ),
				array( 'jquery' )
			);

			/**
			 * Creates a JS variable KoaoUploader.defaultImageUrl
			 */
			wp_localize_script( 'koao-uploader', 'KoaoUploader', array(

				'defaultImageUrl' => KOAO::get_themeable_asset_url('generic-taxonomy-icon'),

			));
		}
	}

	/**
	 * Try to determine current taxonomy and see if it has this helper extension enabled.
	 *
	 * @return bool
	 */
	static function screen_supports_uploader() {

		global $wp_taxonomies, $pagenow;

		do {

			static $supports_uploader;

			if ( isset( $supports_uploader ) ) {
				/**
				 * This needs to be calculated only once per page load.
				 */
				break;
			}

			$supports_uploader = false;

			if ( 'edit-tags.php' !== $pagenow ) {
				$action = sanitize_key( filter_input( INPUT_POST, 'action', FILTER_SANITIZE_STRING ) );
				if ( 'admin-ajax.php' !== $pagenow || $action === 'add-tag' || $action === 'inline-save-tax') {
					break;
				}
			}

			if ( ! ( $taxonomy = WPLib::current_screen()->taxonomy ) ) {
			 	break;
			}

			if ( ! isset( $wp_taxonomies[ $taxonomy ] ) ) {
			 	break;
			}

			$taxonomy_object = $wp_taxonomies[ $taxonomy ];

			if ( ! isset( $taxonomy_object->koao_uploader ) ) {
				break;
			}

			$supports_uploader = $taxonomy_object->koao_uploader;



		} while ( false );

		return $supports_uploader;

	}

	/**
	 * Extend Quick Edit panel with an image field.
	 *
	 * @param $column_name
	 */
	static function _quick_edit_custom_box ( $column_name, $screen, $taxonomy ) {

		if ( 'thumb' === $column_name && 'edit-tags' === $screen && self::screen_supports_uploader() ) {

			$uploader = new KOAO_Uploader();
			$uploader->the_template( 'taxonomy-image-quick-edit' );

		}

	}

	/**
	 * Image field to append to Add New Term form
	 */
	static function _add_form_fields( $taxonomy ) { ?>

		<div class="koao-uploader form-field">
			<label for="koao_image_url"><?php esc_html_e( 'Image', 'koao-theme' ); ?></label>
			<span>
			<img class="taxonomy-image" src="<?php echo KOAO::get_themeable_asset_url('generic-taxonomy-icon'); ?>">
			</span><br>
			<input type="text" name="koao_image_url" id="koao_image_url" value="">
			<br>
			<button class="image upload button"> <?php esc_html_e( 'Upload/Add image', 'koao-theme' ); ?></button>
		</div>

		<?php

	}

	/**
	 * Add Image column to Terms admin list.
	 *
	 * @access public
	 *
	 * @param mixed $columns
	 *
	 * @return array
	 */
	static function _manage_edit_columns( $columns ) {

		$new_columns = array();
		$new_columns['cb']    = $columns['cb'];
		$new_columns['thumb'] = __( 'Image', 'koao-theme' );

		unset( $columns['cb'] );

		return array_merge( $new_columns, $columns );
	}

	/**
	 * Change 'insert into post' to 'use this image' in media popup.
	 *
	 * @param $safe_text
	 * @param $text
	 *
	 * @return mixed
	 */
	static function _attribute_escape( $safe_text, $text ) {

		return str_replace(
			__( 'Insert into Post', 'koao-theme' ),
			__( 'Use this image', 'koao-theme' ),
			$text
		);

	}

	/**
	 * Image field to append to Edit Term form
	 *
	 * @param int $term_id
	 * @param string $taxonomy
	 */
	static function _edit_form_fields( $term, $taxonomy ) {

		if ( $term_item = KOAO::dispense_term_item( $term, $taxonomy ) ) :
		?>

		<tr class="koao-uploader form-field">
		<th scope="row" valign="top"><label for="koao_image_url"><?php esc_html_e( 'Image', 'koao-theme' ); ?></label></th>
		<td>
			<img class="taxonomy-image" src="<?php echo $term_item->get_thumbnail_url( 'use_default=1' ); ?>"><br>
			<input type="text" id="koao_image_url" name="koao_image_url" value="<?php $term_item->the_image_url(); ?>"><br>
			<button class="image upload button"><?php esc_html_e( 'Upload/Add image', 'koao-theme' ); ?></button>
			<button class="image remove button"><?php esc_html_e( 'Remove image', 'koao-theme' ); ?></button>
		</td>
		</tr>

		<?php
		endif;
	}

	/**
	 * Render Thumbnail on terms admin list.
	 *
	 * @param mixed $row
	 * @param string $column_name
	 * @param int $term_id
	 *
	 * @return array
	 */
	static function _manage_custom_column( $row, $column_name, $term_id ) {

		if ( 'thumb' === $column_name && self::screen_supports_uploader() ) {

			$term_item = self::_dispense_screen_term_item( $term_id );

			$img = WPLib::get_img(
				$term_item->get_image_url( 'koao-admin-thumb', 'use_default=>1' ),
				array(
					'class'       => 'wp-post-image',
					'alt_text'    => __( 'Thumbnail', 'koao-theme' ),
				)
			);

			echo "<span>{$img}</span>";
		}

	}

	/**
	 * @param int $term_id
	 */
	static function _edit_term( $term_id ) {

		self::_maybe_update_image_meta( $term_id );

	}

	/**
	 * @param int $term_id
	 */
	static function _create_term( $term_id ) {

		self::_maybe_update_image_meta( $term_id );

	}

	/**
	 * @param int $term_id
	 */
	private static function _maybe_update_image_meta( $term_id ) {

		if ( isset( $_POST[ 'koao_image_url' ] ) && self::screen_supports_uploader() ) {

			$term_item = self::_dispense_screen_term_item( $term_id );
			$term_item->update_image_url( filter_input( INPUT_POST, 'koao_image_url', FILTER_SANITIZE_URL ) );

		}


	}

	/**
	 * @param int $term_id
	 *
	 * @return KOAO_Term_Base
	 */
	private static function _dispense_screen_term_item( $term_id ) {

		return KOAO::dispense_term_item( $term_id, WPLib::current_screen()->taxonomy );

	}

}

KOAO_Uploaders::on_load();
