<?php

/**
 * Class KOAO_Exception_Requests
 */
class KOAO_Exception_Requests extends WPLib_Post_Module_Base {

	const POST_TYPE      = 'koao-except-request'; /* TODO: add to WPLib github -- CPT registration fails silently, when CPT name is longer than 20 symbols */
	const MODULE_NAME    = 'post-type-exception-request';
	const INSTANCE_CLASS = 'KOAO_Exception_Request';

	static $_form_field_definitions = null;

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'Exception Requests', 'koao-theme' ),
			'singular_name' => __( 'Exception Request', 'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'Exception Requests', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => false,
			'show_ui'      => true,
			'menu_icon'    => 'dashicons-editor-unlink',
			'hierarchical' => false,
			'supports'     => array(
				'page-attributes'
			),
		) );

		/**
		 * Edit fields
		 */
		self::add_class_action( 'edit_form_after_title' );
		self::add_class_action( 'wp_insert_post_data' );
		self::add_class_action( 'save_post' );

		self::add_class_action( 'admin_enqueue_scripts' );

		self::add_class_action('wp_ajax_create_exception_request');
		self::add_class_action('wp_ajax_nopriv_create_exception_request');
	}

	/**
	 *
	 */
	static function _wp_ajax_create_exception_request() {
		self::_create_exception_request();
	}

	/**
	 *
	 */
	static function _wp_ajax_nopriv_create_exception_request() {
		self::_create_exception_request();
	}

	/**
	 *
	 */
	static function _create_exception_request() {

		do {

			$form_name = KOAO::short_prefix() . self::var_name();

			if ( ! ( $http_form = KOAO::get_http_POST( $form_name, false ) ) ) {
				break;
			}

			if ( empty( $http_form['agency_name'] ) ) {
				break;
			}

			$_post = array(
				'post_type'   => self::POST_TYPE,
				'post_title'  => sanitize_title( $http_form['agency_name'] ),
				'post_status' => 'pending'
			);

			$post_id = wp_insert_post( $_post, true );

			if ( is_wp_error( $post_id ) ) {
				/**
				 * wp_send_json_error() calls die()
				 */
				wp_send_json_error();
			}

			$notified = (bool) self::do_email_admin_notification( $post_id );

			/**
			 * wp_send_json_success() calls die()
			 */
			wp_send_json_success( array(
				'notified' => $notified
			));

		} while (false);

	}

	/**
	 * @param $post_id int the ID of existing Exception Request post
	 *
	 * @return bool
	 */
	static function do_email_admin_notification( $post_id ) {

		$req = new KOAO_Exception_Request( $post_id );

		$to = get_option('admin_email');

		$site = get_bloginfo('name');

		$site = $site ? $site : __( 'Agency Ops', 'koao-theme' );

		$subject = sprintf(
			__('%s Exception Request for %s', 'koao-theme'),
			esc_attr( $site ),
			esc_attr( $req->agency_name() )
		);

		$form_name = KOAO::short_prefix() . self::var_name(); /* 'koao_exception_request' */;
		$fields    = self::form_field_definitions();

		$message = KOAO::get_form_contents( $form_name, $fields, array('entry' => $req, 'readonly' => true ));

        return wp_mail( $to, $subject, $message );
	}

	/**
	 * @param WP_Post $post
	 */
	static function _edit_form_after_title( $post ) {

		if ( self::POST_TYPE === $post->post_type ) {
			?>
			<div id="exception-request-after-title" class="postbox">
			<div class="handlediv" title="<?php esc_attr_e( 'Click to toggle', 'koao-theme' ); ?>"><br></div>
			<h3 class="hndle"><span><?php _e( 'Exception Request', 'koao-theme' ); ?></span></h3>
			<div class="inside"><?php

			$exception_request = new KOAO_Exception_Request( $post );
			$form_name = KOAO::short_prefix() . self::var_name(); /* 'koao_exception_request' */;

			$fields    = self::form_field_definitions();

			echo KOAO::get_form_contents( $form_name, $fields, array('entry' => $exception_request ));

			wp_nonce_field( '_exception_request_meta_nonce', 'exception_request_nonce' );

			echo '</div></div>';

		}
	}

	/**
	 * Set Agency Name from the form entry as a title for this post.
	 *
	 * @param array $data
	 * @param array $postarr
	 *
	 * @return array
	 */
	static function _wp_insert_post_data( $data, $postarr ) {

		if ( $data['post_type'] === self::POST_TYPE ) {
			$group = KOAO::short_prefix() . self::var_name();
			if ( isset( $postarr[ $group ], $postarr[ $group ]['agency_name'] ) ) {
				$data['post_title'] = $postarr[ $group ]['agency_name'];
			}
		}

		return $data;
	}

	/**
	 * @param $post_id
	 */
	static function _save_post( $post_id ) {

		do {

			if ( self::POST_TYPE !== get_post_type( $post_id ) ) {
				break;
			}

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				break;
			}

			if ( ! wp_verify_nonce( KOAO::get_http_POST( 'exception_request_nonce' ), '_exception_request_meta_nonce' ) ) {
				break;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				if ( ! self::doing_ajax()) {
					break;
				}
			}

			KOAO::update_post_meta_from_POST( $post_id,
				KOAO::short_prefix() . self::var_name(),
				KOAO::form_field_sanitizers()
			);

		} while ( false );

	}

	/**
	 * @return KOAO_Exception_Request[]
	 */
	static function requests_list() {

		return self::get_requests_list( array() );

	}

	/**
	 * @param string|array|WPLib_Query $query
	 * @param array $args
	 *
	 * @return WPLib_Post_List_Base
	 */
	static function get_requests_list( $query, $args = array() ) {

		$md5 = md5( serialize( array( $query, $args ) ) );
		$cache_key = "koao-requests-list[{$md5}]";

		if ( ! ( $list = WPLib::cache_get( $cache_key ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 12,
				'order'          => 'ASC',
				'orderby'        => 'title menu_order',
			) );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			) );

			$list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $list, null, 15 * 60 );

		}

		return $list;

	}

	static function the_frontend_editable_form_html() {

		$form_name = KOAO::short_prefix() . self::var_name(); /* 'koao_exception_request' */
		$fields    = self::form_field_definitions();
		echo KOAO::get_form_contents( $form_name, $fields );

		/* this is "action" parameter to be submitted to ajax-admin.php */
		echo '<input type="hidden" name="action" value="create_exception_request">';

		wp_nonce_field( '_exception_request_meta_nonce', 'exception_request_nonce' );

	}

	static function form_field_definitions( ) {

		static $_form_field_definitions;

		if ( is_null( $_form_field_definitions )) {

			$defaults = array(
				'contact_section' => array(
					'label'     => __('Contact Information', 'koao-theme'),
					'type'      => 'section',
				),
				'contact_name'  => array(
					'label'     => __('Your Name', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'text'
				),
				'contact_position'  => array(
					'label'     => _x('Title', 'work position', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'text'
				),
				'contact_email' => array(
					'label'     => __('E-mail', 'koao-theme'),
					'sanitizer' => 'email',
					'type'      => 'email',
				),
				'contact_phone' => array(
					'label'     => __('Phone', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'tel',
				),
				'contact_group_vp'  => array(
					'label'     => __('VP of your group', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'text',
				),
				'agency_section' => array(
					'label'      => __('Agency Information', 'koao-theme'),
					'type'       => 'section',
				),
				'agency_name'   => array(
					'label'     => __('Agency Name', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'text',
				),
				'agency_type_id'=> array(
					'label'     => __('Service Category', 'koao-theme'),
					/* will store term_id from Agency_Type taxonomy */
					'sanitizer' => 'int',
					/* reference to a callable */
					'type'      => 'custom',
					'renderer'  => array( 'KOAO','the_select_service_categories_html' )
				),
				'agency_contracted' => array(
					'label'     => __('Is this agency under contract with TCCC?', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'radio',
					'options'   => array(
						'yes'   => __('Yes', 'koao-theme'),
						'no'    => __('No',  'koao-theme' ),
					)
				),
				'capabilities_section' => array(
					'label'     => __('Agency Capabilities', 'koao-theme'),
					'type'      => 'section',
				),
				'agency_reviewed'   => array(
					'label'     => __('Has a capabilities review been conducted by Agency Operations?', 'koao-theme'),
					'sanitizer' => 'text',
					'type'      => 'radio',
					'options'   => array(
						'yes'   => __('Yes', 'koao-theme'),
						'no'    => __('No',  'koao-theme' ),
						'maybe' => __("I don't know", 'koao-theme'),
					)
				),
				'justification'   => array(
					'label'       => __('Business justification for exception request:', 'koao-theme'),
					'sanitizer'   => 'text',
					'type'        => 'radio',
					'options'     => array(
						'niche'   => __('Agency has niche offering that cannot be met by other agencies on roster', 'koao-theme'),
						'partner' => __('Customer / Promotional partner has required that agency be used', 'koao-theme'),
						'fees'    => __('Agency has similar skillset to roster agencies but lower fees', 'koao-theme'),
						'other'   => __('Other', 'koao-theme'),
					)
				),
			);

			$_form_field_definitions = apply_filters('koao_form_field_definitions', $defaults, __CLASS__ );
		}

		return $_form_field_definitions;
	}

	static function form_field_sanitizers() {

		return KOAO::get_form_sanitizers( self::form_field_definitions() );

	}

	static function _admin_enqueue_scripts( $hook ) {

		$screen = get_current_screen();

		if ( $screen->post_type === self::POST_TYPE && ('post.php' === $hook || 'post-new.php' === $hook )) {
			wp_enqueue_style( 'exception-request-admin', WPLib::get_asset_url('css/exception-request-admin.css', 'KOAO_Exception_Requests') );
		}
	}

	static function the_select_service_categories_html( $field, $value = null, $args = array() ) {

		$args = wp_parse_args( $args, array(
			'is_readonly' => false,
			'control_id'  => '',
			'name'        => ''
		));

		$agency_types = KOAO::agency_types_list();
		if ( count( $agency_types ) ) {
			printf('<label class="field %s select custom" for="%s"><span class="label-text">%s</span>',
				esc_attr( $args['name'] ),
				esc_attr( $args['control_id'] ),
				esc_html( $field['label'] )
			);
			printf('<select name="%s" id="%s" %s>',
				esc_attr( $args['name'] ),
				esc_attr( $args['control_id'] ),
				$args['is_readonly'] ? 'disabled="disabled"' : ''
			);
			printf( '<option value="" %s></option>', selected( $value, '' ) );

			foreach ( $agency_types as $agency_type ) {
				$term_id = $agency_type->term_id();
				printf('<option value="%s" %s>%s</option>',
					$term_id,
					selected( $value, $term_id ),
					$agency_type->get_term_name_html()
				);
			}
			echo '</select></label>';
		}
	}
}

KOAO_Exception_Requests::on_load();
