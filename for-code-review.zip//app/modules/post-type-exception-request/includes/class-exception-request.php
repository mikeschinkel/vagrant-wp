<?php

/**
 * KOAO_Exception_Request
 *
 * @property KOAO_Exception_Request_Model $model
 * @property KOAO_Exception_Request_View $view
 * @mixin KOAO_Exception_Request_Model
 * @mixin KOAO_Exception_Request_View
 *
 */
class KOAO_Exception_Request extends WPLib_Post_Base {

	const POST_TYPE = KOAO_Exception_Requests::POST_TYPE;
	const VAR_NAME = 'exception_request';

}