<?php

/**
 * Class KOAO_Exception_Request_Model
 */
class KOAO_Exception_Request_Model extends WPLib_Post_Model_Base {

	function contact_name() {
		return $this->get_meta_value( 'contact_name' );
	}

	function contact_position() {
		return $this->get_meta_value( 'contact_position' );
	}

	function contact_email() {
		return $this->get_meta_value( 'contact_email' );
	}

	function contact_phone() {
		return $this->get_meta_value( 'contact_phone' );
	}

	function contact_group_vp() {
		return $this->get_meta_value( 'contact_group_vp' );
	}

	function agency_name() {
		return $this->title();
	}

	function agency_type_id() {
		return $this->get_meta_value( 'agency_type_id' );
	}

	function agency_contracted() {
		return $this->get_meta_value( 'agency_contracted' );
	}

	function agency_reviewed() {
		return $this->get_meta_value( 'agency_reviewed' );
	}

	function justification() {
		return $this->get_meta_value( 'justification' );
	}

}
