<?php

/**
 * Class KOAO_Exception_Request_View
 *
 * @property KOAO_Exception_Request $item
 * @property KOAO_Exception_Request_Model $model
 *
 * @method KOAO_Exception_Request_Model model()
 *
 * @mixin KOAO_Exception_Request
 */
class KOAO_Exception_Request_View extends WPLib_Post_View_Base {


}