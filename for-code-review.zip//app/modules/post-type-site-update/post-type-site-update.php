<?php

/**
 * Class KOAO_Site_Updates
 */
class KOAO_Site_Updates extends WPLib_Post_Module_Base {

	const POST_TYPE      = 'koao-site-update';
	const MODULE_NAME    = 'post-type-site-update';
	const INSTANCE_CLASS = 'KOAO_Site_Update';

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'Site Updates', 'koao-theme' ),
			'singular_name' => __( 'Site Update',  'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'Site Updates', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => false,
			'show_ui'      => true,
			'menu_icon'    => 'dashicons-desktop',
			'hierarchical' => false,
			'supports'     => array(
				'title',
				'editor',
				'page-attributes',
			),
		) );

	}

	/**
	 * @return KOAO_Site_Update[]
	 */
	static function site_updates_list() {

		return self::get_site_updates_list( array() );

	}

	/**
	 * @param string|array|WPLib_Query $query
	 * @param array $args
	 *
	 * @return WPLib_Post_List_Base
	 */
	static function get_site_updates_list( $query, $args = array() ) {

		$md5 = md5( serialize( array( $query, $args ) ) );

		if ( ! ( $list = WPLib::cache_get( $cache_key = "koao-site-updates-list[{$md5}]" ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish', /* this means it will not retrieve "expired" posts */
				'posts_per_page' => 50,
				'order'          => 'ASC',
				'orderby'        => 'title menu_order',
			) );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			));

			$list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $list, null, 15 * 60 );

		}

		return $list;

	}

}

KOAO_Site_Updates::on_load();
