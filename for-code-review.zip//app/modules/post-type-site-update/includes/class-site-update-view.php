<?php

/**
 * Class KOAO_Site_Update_View
 *
 * @property KOAO_Site_Update $item
 * @property KOAO_Site_Update_Model $model
 *
 * @method KOAO_Site_Update_Model model()
 *
 * @mixin KOAO_Site_Update
 */
class KOAO_Site_Update_View extends WPLib_Post_View_Base {

}