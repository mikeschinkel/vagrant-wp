<?php

/**
 * Class KOAO_Site_Update_Model
 */
class KOAO_Site_Update_Model extends WPLib_Post_Model_Base {



}