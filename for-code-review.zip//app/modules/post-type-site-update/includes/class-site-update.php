<?php

/**
 * KOAO_Site_Update
 *
 * @property KOAO_Site_Update_Model $model
 * @property KOAO_Site_Update_View $view
 * @mixin KOAO_Site_Update_Model
 * @mixin KOAO_Site_Update_View
 *
 */
class KOAO_Site_Update extends WPLib_Post_Base {

	const POST_TYPE = KOAO_Site_Updates::POST_TYPE;
	const RESOURCE_POST_TYPE = self::POST_TYPE;
	const VAR_NAME = 'site_update';

}