<?php

/**
 * Class KOAO_Featured_Slides
 */
class KOAO_Featured_Slides extends WPLib_Post_Module_Base {

	const POST_TYPE = 'koao-slide';
	const MODULE_NAME = 'post-type-featured-slide';
	const INSTANCE_CLASS = 'KOAO_Featured_Slide';

	const MAX_SLIDES = 7;

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'Featured Slides', 'koao-theme' ),
			'singular_name' => __( 'Featured Slide', 'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'Featured Slides', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => false,
			'show_ui'      => true,
			'menu_icon'    => 'dashicons-portfolio',
			'hierarchical' => false,
			'supports'     => array(
				'title',
				'thumbnail',
				'page-attributes'
			),
		) );

		add_action( 'do_meta_boxes', array( __CLASS__, '_do_meta_boxes' ) );

	}

	static function _do_meta_boxes() {
		remove_meta_box( 'postimagediv', self::POST_TYPE . '_image_box', 'side' );
		add_meta_box( 'postimagediv', __( 'Featured Image', 'koao-theme' ), 'post_thumbnail_meta_box', self::POST_TYPE, 'normal', 'high' );
	}

	/**
	 * @return KOAO_Featured_Slide[]
	 */
	static function featured_slides_list() {
		return self::get_featured_slides_list( array() );
	}

	/**
	 * @param string|array|WPLib_Query $query
	 * @param array $args
	 *
	 * @return WPLib_Post_List_Base
	 */
	static function get_featured_slides_list( $query, $args = array() ) {

		$md5 = md5( serialize( array( $query, $args ) ) );
		$cache_key = "koao-featured-slides-list[{$md5}]";

		if ( ! ( $slides_list = WPLib::cache_get( $cache_key ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => self::MAX_SLIDES,
				'order'          => 'ASC',
				'orderby'        => 'menu_order',
				KOAO::META_QUERY_KEY  => array(
					array(
						'key'     => '_thumbnail_id',
						'value'   => '',
						'compare' => '!=',
					)
				),
			) );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			) );

			$slides_list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $slides_list, null, 15 * 60 );

		}

		return $slides_list;

	}

}

KOAO_Featured_Slides::on_load();
