<?php

/**
 * KOAO_Featured_Slide
 *
 * @property KOAO_Featured_Slide_Model $model
 * @property KOAO_Featured_Slide_View $view
 * @mixin KOAO_Featured_Slide_Model
 * @mixin KOAO_Featured_Slide_View
 *
 */
class KOAO_Featured_Slide extends WPLib_Post_Base {

	const POST_TYPE = KOAO_Featured_Slides::POST_TYPE;

}