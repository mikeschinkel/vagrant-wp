<?php

/**
 * Class KOAO_Featured_Slide_Model
 */
class KOAO_Featured_Slide_Model extends WPLib_Post_Model_Base {

}