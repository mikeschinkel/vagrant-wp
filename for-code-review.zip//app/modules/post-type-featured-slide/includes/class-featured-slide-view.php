<?php

/**
 * Class KOAO_Featured_Slide_View
 *
 * @property KOAO_Featured_Slide $item
 * @property KOAO_Featured_Slide_Model $model
 *
 * @method KOAO_Featured_Slide_Model model()
 *
 * @mixin KOAO_Featured_Slide
 */
class KOAO_Featured_Slide_View extends WPLib_Post_View_Base {


}