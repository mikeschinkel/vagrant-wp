<?php

/**
 * Class KOAO_People
 */
class KOAO_People extends WPLib_Post_Module_Base {

	const POST_TYPE = 'koao-person';
	const MODULE_NAME = 'post-type-person';
	const INSTANCE_CLASS = 'KOAO_Person';

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'People', 'koao-theme' ),
			'singular_name' => __( 'Person', 'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'People', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => false,
			'show_ui'      => true,
			'menu_icon'    => 'dashicons-id',
			'hierarchical' => false,
			'supports'     => array(
				'thumbnail',
				'page-attributes'
			),
		) );

		/**
		 * Edit fields
		 */
		self::add_class_action( 'edit_form_after_title' );
		self::add_class_action( 'wp_insert_post_data' );
		self::add_class_action( 'save_post' );

		//add_action( 'save_post', array(__CLASS__,'_save_post'), 9, 3 );

		self::add_class_action( 'do_meta_boxes' );

		/**
		 * Enable Category taxonomy for this post type.
		 */
		self::add_class_action( 'init', 12 );

	}

	static function _init_12() {
		register_taxonomy_for_object_type( WPLib_Categories::TAXONOMY, self::POST_TYPE );
	}

	static function _do_meta_boxes() {

		remove_meta_box( 'postimagediv', self::POST_TYPE . '_image_box', 'side' );
		add_meta_box( 'postimagediv', __( 'Portrait', 'koao-theme' ), 'post_thumbnail_meta_box', self::POST_TYPE, 'normal', 'high' );
	}

	/**
	 * @param WP_Post $post
	 */
	static function _edit_form_after_title( $post ) {

		if ( self::POST_TYPE === $post->post_type ) :
			?>
			<div id="person-after-title" class="postbox">
				<div class="handlediv" title="<?php _e( 'Click to toggle' ); ?>"><br></div>
				<h3 class="hndle"><span><?php _e( 'Person Details', 'koao-theme' ); ?></span></h3>
				<div class="inside">
				<?php

					$person = new KOAO_Person( $post );
					$person->the_template( 'person-fields' );

					wp_nonce_field( '_person_meta_nonce', 'person_nonce' );

				?>
				</div>
			</div>
			<?php
		endif;

	}

	/**
	 * Customize the post title
	 *
	 * @param array $data
	 * @param array $postarr
	 *
	 * @return array
	 */
	static function _wp_insert_post_data( $data, $postarr ) {
		if ( $data['post_type'] === self::POST_TYPE ) {
			$group = KOAO::short_prefix() . self::var_name();
			if ( isset( $postarr[ $group ], $postarr[ $group ]['full_name'] ) ) {
				$data['post_title'] = $postarr[ $group ]['full_name'];
			}
		}

		return $data;
	}

	/**
	 * @param int $post_id
	 */
	static function _save_post( $post_id ) {

		do {

			if ( self::POST_TYPE !== get_post_type( $post_id ) ) {
				break;
			}

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				break;
			}

			if ( ! wp_verify_nonce( KOAO::get_http_POST('person_nonce'), '_person_meta_nonce' ) ) {
				break;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				break;
			}

			KOAO::update_post_meta_from_POST( $post_id,
				KOAO::short_prefix() . self::var_name(),
				array(
					'position' => 'text',
					'email'    => 'email',
					'phone'    => 'text',
				)
			);

		} while ( false );

	}

	/**
	 * Alias method for persons_list().
	 *
	 * @return KOAO_Person[]
	 */
	static function people_list() {
		return self::persons_list();
	}

	/**
	 * @return KOAO_Person[]
	 */
	static function persons_list() {

		return self::get_persons_list( array() );

	}

	/**
	 * @param array|string|WPLib_Query $query
	 * @param array $args
	 *
	 * @return KOAO_Person[]
	 */
	static function get_persons_list( $query, $args = array() ) {

		$md5 = md5( serialize( array( $query, $args ) ) );
		$cache_key = "koao-persons-list[{$md5}]";

		if ( ! ( $list = WPLib::cache_get( $cache_key ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 12,
				'order'          => 'ASC',
				'orderby'        => 'title menu_order',
			) );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			) );

			$list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $list, null, 15 * 60 );

		}

		return $list;

	}

}

KOAO_People::on_load();
