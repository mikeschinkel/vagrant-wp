<?php
/**
 * @var KOAO_Person $person
 */
?>
<style>
	.person-fields .field {
		margin: 1em 0;
		display: block;
	}

	.person-fields .label-text {
		display: block;
		font-weight: bold;
	}

	.person-fields legend {
		font-size: 1.25em;
		font-weight: bold;
	}
</style>

<div class="person-fields">

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Full Name', 'koao-theme' ); ?></span>
		<input type="text" name="koao_person[full_name]"
		       value="<?php $person->the_full_name_attr(); ?>">
	</label>

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Position', 'koao-theme' ); ?></span>
		<input type="text" name="koao_person[position]"
		       value="<?php $person->the_position_attr(); ?>">
	</label>

	<fieldset>

		<legend><?php esc_html_e( 'Contact Information', 'koao-theme' ); ?></legend>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Email Address', 'koao-theme' ); ?></span>
			<input type="email" name="koao_person[email]"
			       value="<?php $person->the_email_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Phone Number', 'koao-theme' ); ?></span>
			<input type="text" name="koao_person[phone]"
			       value="<?php $person->the_phone_attr(); ?>">
		</label>

	</fieldset>

</div>
