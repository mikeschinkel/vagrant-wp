<?php

/**
 * KOAO_Person
 *
 * @property KOAO_Person_Model $model
 * @property KOAO_Person_View $view
 * @mixin KOAO_Person_Model
 * @mixin KOAO_Person_View
 *
 */
class KOAO_Person extends WPLib_Post_Base {

	const POST_TYPE = KOAO_People::POST_TYPE;
	const VAR_NAME = 'person';

}
