<?php

/**
 * Class KOAO_Person_View
 *
 * @property KOAO_Person $item
 * @property KOAO_Person_Model $model
 *
 * @method KOAO_Person_Model model()
 *
 * @method void the_full_name_html()
 * @method void the_full_name_attr()
 * @method void the_position_html()
 * @method void the_department_html()
 * @method void the_email_html()
 * @method void the_phone_html()
 * @method void the_categories_html( $args = array() )
 * @method void the_contacts_html( $args = array() )
 *
 * @method void the_position_attr()
 * @method void the_email_attr()
 * @method void the_phone_attr()
 *
 * @mixin KOAO_Person
 */
class KOAO_Person_View extends WPLib_Post_View_Base {

	/**
	 * @param array $args
	 *
	 * @return string
	 */
	function get_categories_html( $args = array() ) {

		$model = $this->model();

		if ( ! $model->has_post() ) {
			return '';
		}

		/**
		 * @todo Saru: Can we use WPLib::get_html_unordered_list_html() for this?
		 */
		$cats = $model->categories();

		if ( empty( $cats ) )
			return '&mdash;';

		$cats = wp_list_pluck( $cats, 'name' );

		$args = wp_parse_args( $args, array(
			'html_template' => '<ul class="%2$s">%1$s</ul>',
			'class'         => 'cats',
			'before'        => '<li>',
			'after'         => '</li>',
			'separator'     => _x( '', 'a separator used between person category terms', 'wplib' ),
		) );

		$separator = $args['after'] . $args['separator'] . $args['before'];

		$html = $args['before'] . join( $separator, array_map('esc_html', $cats ) ) . $args['after'];

		return sprintf( $args['html_template'], $html, $args['class'] );

	}

	/**
	 * @param string $size
	 * @param array $args {
	 *
	 *      @type string $height height for person icon, to be presented when featured image is not set.
	 *      @type string $width width for person icon, to be presented when featured image is not set.
	 *
	 * }
	 */
	function the_featured_image_html( $size = 'post-thumbnail', $args = array() ) {


		if ( ! $this->has_post() ) {
			return;
		}

		if ( $this->has_featured_image() ) {

			echo $this->get_featured_image_html( $size, "title={$this->get_full_name_attr()}" );

		} else {

			$args = wp_parse_args( $args, array(
				'height' => '100px',
				'width'  => '100px'
			) );

			WPLib::the_img(
				KOAO::get_themeable_asset_url( 'person-icon' ),
				sprintf('height=%s&width=%s&title=%s', $args['height'], $args['width'], $this->get_full_name_attr())
			);
		}

	}

	/**
	 * Return an HTML Unordered List (<ul>) of contact details (email, phone).
	 *
	 * @param array $args {
	 *
	 *      @type string $before
	 *      @type string $class
	 *      @type string[]|string $attributes
	 *      @type string $before_elements
	 *      @type string $before_li
	 *      @type string $li_class
	 *      @type string[]|string $li_attributes
	 *      @type string $before_text
	 *      @type string $after_text
	 *      @type string $after_li
	 *      @type string $after_elements
	 *      @type string $after
	 *      @type callable $filter
	 *
	 * }
	 *
	 * @return string
	 */
	function get_contacts_html( $args = array() ) {

		if ( ! $this->has_post()) {

			$contacts_html = null;

		} else {

			$args = wp_parse_args( $args, array(

				'filter' => function ( $args ) {

					$args['class'] = ltrim( "{$args['class']} person-{$args['index']}" );

					return $args;

				},

			) );

			$contacts_html = WPLib::get_html_unordered_list_html( $this->contacts(), $args );

		}

		return $contacts_html;

	}

	/**
	 * @return string|void
	 */
	function get_full_name_attr() {

		return esc_attr( $this->full_name() );
	}

}
