<?php

/**
 * Class KOAO_Person_Model
 */
class KOAO_Person_Model extends WPLib_Post_Model_Base {

	/**
	 * @return string
	 */
	function full_name() {
		return $this->title();
	}

	/**
	 * @return string
	 */
	function position() {
		return $this->get_meta_value( 'position' );
	}

	/**
	 * @return string
	 */
	function email() {
		return $this->get_meta_value( 'email' );
	}

	/**
	 * @return string
	 */
	function phone() {
		return $this->get_meta_value( 'phone' );
	}

	/**
	 * @return string
	 */
	function department() {

		$terms = wp_get_object_terms( $this->ID(), KOAO_Department::TAXONOMY );
		if ( $terms && is_array( $terms ) ) {
			$term = array_shift( $terms );
			return $term->name;
		}

		return '';
	}

	/**
	 * @return WP_Term[]
	 */
	function categories() {
		return wp_get_object_terms( $this->ID(), WPLib_Category::TAXONOMY );
	}


	/**
	 * Get a list with contact details (email, phone).
	 *
	 * @return string[]
	 */
	function contacts() {
		return array_filter( array(
			'email' => $this->email(),
			'phone' => $this->phone(),
		));
	}

}
