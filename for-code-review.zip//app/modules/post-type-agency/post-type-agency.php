<?php

/**
 * Class KOAO_Agencies
 */
class KOAO_Agencies extends WPLib_Post_Module_Base {

	const POST_TYPE      = 'koao-agency';
	const MODULE_NAME    = 'post-type-agency';
	const INSTANCE_CLASS = 'KOAO_Agency';

	const POSTS_PER_PAGE = 12;

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'Agencies', 'koao-theme' ),
			'singular_name' => __( 'Agency', 'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'Agencies', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => true,
			'menu_icon'    => 'dashicons-groups',
			'hierarchical' => false,
			'supports'     => array(
				'thumbnail',
				'page-attributes'
			),
			'rewrite'      => array(
				'slug' => 'agencies',
				'with_front' => false,
			)
		) );

		/**
		 * Edit fields
		 */
		self::add_class_action( 'edit_form_after_title' );
		self::add_class_action( 'wp_insert_post_data' );
		self::add_class_action( 'save_post' );
		self::add_class_action( 'add_meta_boxes' );

		/*
		 * Serve roster file, maybe
		 */
		self::add_class_action( 'template_redirect' );

		/*
		 * Get a batch of agency cards to enable pagination on Agency Type page
		 */
		self::add_class_action('wp_ajax_get_paged_agencies_list');
		self::add_class_action('wp_ajax_nopriv_get_paged_agencies_list');
	}

	static function _wp_ajax_get_paged_agencies_list() {
		self::_get_paged_agencies_list();
	}

	static function _wp_ajax_nopriv_get_paged_agencies_list() {
		self::_get_paged_agencies_list();
	}

	/**
	 * Called from AJAX context.
	 *
	 * @future We need to come up with a (method naming?) contention for methods that
	 *         get their input from $_GET and $_POST vs. explicit parameters so that
	 *         it is easier to understand and to "lint" these types of methods.
	 */
	protected static function _get_paged_agencies_list() {

		$paged = (int) filter_input( INPUT_POST, 'paged', FILTER_SANITIZE_NUMBER_INT );
		if ( 0 === $paged ) {
			exit;
		}

		$agency_type_id = (int) filter_input( INPUT_POST, 'agency_type_id', FILTER_SANITIZE_NUMBER_INT );
		if ( 0 === $agency_type_id ) {
			exit;
		}

		$posts_per_page = (int) filter_input( INPUT_POST, 'posts_per_page', FILTER_SANITIZE_NUMBER_INT );
		$posts_per_page  = 0 !== $posts_per_page
	        ? $posts_per_page
			: self::POSTS_PER_PAGE;

		$agencies = self::get_agency_list(
			array( 'posts_per_page' => $posts_per_page, 'paged' => $paged ),
			array( 'agency_type_id' => $agency_type_id )
		);

		if ( count( $agencies ) ) {

			foreach ( $agencies as $agency ) {
				echo '<li>';
				$agency->the_template( 'cards/agency' );
				echo '</li>';
			}

		} else {
			echo '<h5>';
			esc_html_e('There are no more agencies in this category.', 'koao-theme');
			echo '</h5>';
		}

		exit;

	}

	/**
	 * Output roster CSV file, maybe.
	 */
	static function _template_redirect() {

		do {
			if ( ! filter_input( INPUT_GET, 'roster' ) ) {
				break;
			}

			/**
			 * @future Naming mismatch here is confusing. Agency Type === Service???
			 */
			if ( 0 === ( $agency_type_id = (int) filter_input( INPUT_GET, 'service', FILTER_SANITIZE_NUMBER_INT ) ) ) {
				break;
			}

			if ( ! is_user_logged_in() ) {
				break;
			}

			$agency_type = get_term( $agency_type_id, KOAO_Agency_Type::TAXONOMY );

			if ( $agency_id = (int) filter_input( INPUT_GET, 'agency', FILTER_SANITIZE_NUMBER_INT ) ) {

				$agency_post = get_post( $agency_id );
				$filename = "roster-{$agency_post->post_name}-{$agency_type->slug}.csv";

			} else {

				$filename = "roster-{$agency_type->slug}.csv";

			}

			WPLib::emit_headers( array(
				"Content-Disposition: attachment, filename={$filename}",// Names the download file for the user's browser
				'Cache-Control: no-cache, no-store, must-revalidate',   // Disable caching; HTTP 1.1
				'Pragma: no-cache',                                     // Disable caching; HTTP 1.0
				'Expires: 0',                                           // Disable caching; Proxies
				'Content-Type: text/csv',                               // Sets the mime-type for the browser to correctly interpret the content
			));

			/*
			 * Output first line of headers for CSV file
			 */
			echo
				__( 'Agency Name', 'koao-theme' ),
				__( 'Service Type', 'koao-theme' ),
				__( 'Base Rate', 'koao-theme' ),
				"\n";

			/*
			 * Get the list of agencies to generate for
			 */
			$agency_ids = 0 === $agency_id
				? self::get_roster_agencies( $agency_type_id )
				: array( $agency_id );

			/*
			 * Create argument for get_roster_data only once
			 */
			$agency_data = array( 'agency_type_id' => $agency_type_id );

			/*
			 * Generate the rows of CSV outout
			 */
			foreach ( $agency_ids as $agency_id ) {

				$agency = new KOAO_Agency( $agency_id );
				$agency->set_post($agency_id);
				$row    = $agency->get_roster_data( $agency_data );

				if ( ! empty( $row ) ) {

					echo "{$row}\n";

				}

			}

			exit;

		} while ( false );

	}

	/**
	 * @param $agency_type_id
	 *
	 * @return array
	 */
	static function get_roster_agencies( $agency_type_id ) {
		global $wpdb;

		$cache_key = "koao-roster-agencies[{$agency_type_id}]";

		if ( ! ( $result = KOAO::cache_get( $cache_key ) ) ) {

			$meta_key   = KOAO::_get_raw_meta_fieldname( 'service_rates' );
			$meta_value = "%s:4:\"term\";i:{$agency_type_id};%";

			/*
			 * Usage of a direct database call is discouraged, so below we use a standard meta_query.
			 */
			//$sql = "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '%s' AND meta_value LIKE %s";
			//$sql = $wpdb->prepare( $sql, $meta_key, $meta_value );
			//$result = $wpdb->get_col( $sql );

			$query = array(
				KOAO::META_QUERY_KEY => array(
					KOAO::META_KEY_KEY   => $meta_key,
					KOAO::META_VALUE_KEY => $meta_value,
					'compare'            => 'LIKE'
				)
			);
			$posts = get_posts( $query );

			$result = wp_list_pluck( $posts, 'ID' );

			/*
			 * Expire in 15 minutes
			 */
			KOAO::cache_set( $cache_key, $result, null, 15 * 60 );

		}

		return $result ? $result : array();

	}

	/**
	 * Adds a box to the main column on the Post and Page edit screens.
	 */
	static function _add_meta_boxes() {

		/*
		 * Drop the standard metabox.
		 */
		remove_meta_box( KOAO_Agency_Type::TAXONOMY . 'div', self::POST_TYPE, 'side' );

		/**
		 * Using metaboxes here in order to give some flexibility for the user
		 * and to visually separate Rates and Work Samples from the multitude of other fields.
		 */

		add_meta_box(
			'metabox_agency_rates',
			__( 'Agency Rates', 'koao-theme' ),
			array(__CLASS__, '_metabox_agency_rates'),
			self::POST_TYPE,
			'side'
		);

		add_meta_box(
			'metabox_work_samples',
			__( 'Work Samples', 'koao-theme' ),
			array( __CLASS__, '_metabox_work_samples'),
			self::POST_TYPE,
			'advanced'
		);

	}

	/**
	 * @param WP_Post $post
	 */
	static function _metabox_agency_rates( $post ) {

		$agency = new KOAO_Agency( $post );

		$agency->the_template( 'agency-rates-metabox' );

	}

	/**
	 *
	 */
	static function _metabox_work_samples( $post ) {

		$agency = new KOAO_Agency( $post->ID );
		$agency->the_template('work-samples-metabox');

	}



	/**
	 * @param WP_Post $post
	 */
	static function _edit_form_after_title( $post ) {

		if ( self::POST_TYPE === $post->post_type ) :
			?>
			<div id="agency-after-title" class="postbox">
				<div class="handlediv" title="<?php _e( 'Click to toggle', 'koao-theme' ); ?>"><br></div>
				<h3 class="hndle"><span><?php _e( 'Agency Details', 'koao-theme' ); ?></span></h3>
				<div class="inside">
					<?php

					$agency = new KOAO_Agency( $post );
					$agency->the_template( 'agency-fields' );
					wp_nonce_field( '_agency_meta_nonce', 'agency_nonce' );

					?>
				</div>
			</div>
		<?php
		endif;

	}

	/**
	 * Customize the post title
	 *
	 * @param array $data
	 * @param array $postarr
	 *
	 * @return array
	 */
	static function _wp_insert_post_data( $data, $postarr ) {
		if ( $data['post_type'] === self::POST_TYPE ) {
			$group = KOAO::short_prefix() . self::var_name();
			if ( isset( $postarr[ $group ], $postarr[ $group ]['agency_name'] ) ) {
				$data['post_title'] = $postarr[ $group ]['agency_name'];
			}
		}

		return $data;
	}

	/**
	 * @param $post_id
	 */
	static function _save_post( $post_id ) {

		do {

			if ( self::POST_TYPE !== get_post_type( $post_id ) ) {
				break;
			}

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				break;
			}

			if ( ! wp_verify_nonce( KOAO::get_http_POST( 'agency_nonce' ), '_agency_meta_nonce' ) ) {
				break;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				break;
			}

			KOAO::update_post_meta_from_POST( $post_id,
				KOAO::short_prefix() . self::var_name(),
				array(
					'name'                => 'text',
					'subcategory'         => 'text',
					'agreement_type'      => 'text',
					'start_date'          => 'text',
					'end_date'            => 'text',
					'street_address'      => 'text',
					'address_line_2'      => 'text',
					'address_locality'    => 'text',
					'address_region'      => 'text',
					'postal_code'         => 'text',
					'contact_name'        => 'text',
					'contact_email'       => 'email',
					'office_phone'        => 'text',
					'url'                 => 'url',
				)
			);

			/**
			 * Sanitize fields that require special handling -- service_rates is a JSON array.
			 */

			$agency_rates = 0;

			$agency_info = KOAO::get_http_POST( 'koao_agency' );

			if ( empty( $agency_info['service_rates'] ) ) {
				break;
			}

			$agency_rates = filter_var( $agency_info['service_rates'], FILTER_SANITIZE_SPECIAL_CHARS );

			$agency = new KOAO_Agency( $post_id );

			$agency->update_agency_rates( $agency_rates );

		} while ( false );

	}

	/**
	 * Get a list of all agencies.
	 *
	 * @return KOAO_Agency[]
	 */
	static function agencies_list() {

		return self::get_agency_list( array() );

	}

	/**
	 * @param array $query
	 *
	 * @return int
	 *
	 * @future The logic for this and for get_agency_list() is so similar and related
	 *         so this method should call that method and that method should be
	 *         augmented to support counting. OR they should both call a third
	 *         private function that minimizes the duplication.
	 *         See https://en.wikipedia.org/wiki/Don%27t_repeat_yourself
	 */
	static function get_agencies_total_pages( $query = array() ) {

		$query = wp_parse_args( $query, array(
			'posts_per_page' => self::POSTS_PER_PAGE,
			'agency_type_id' => null,
		));

		do {

			if ( -1 === $query['posts_per_page'] ) {
				$total_pages = 1;
				break;
			}

			if ( $query['agency_type_id'] ) {
				$query[ KOAO::TAX_QUERY_KEY ] = array(
					array(
						'taxonomy' => KOAO_Agency_Type::TAXONOMY,
						'field'    => 'term_id',
						'terms'    => absint( $query['agency_type_id'] ),
					)
				);
			}

			$count = self::_get_agencies_total_count( $query );

			$total_pages = $count
				? absint( ceil( $count / $query['posts_per_page'] ) )
				: 1;

		} while ( false );

		return $total_pages;
	}

	/**
	 * @param array $query
	 *
	 * @return int
	 */
	static function _get_agencies_total_count( $query = array() ) {

		$query = wp_parse_args( $query, array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
		));

		$query['posts_per_page'] = WPLib::max_posts_per_page();
		$query['paged']          = 0;

		$query = new WPLib_Query( $query );

		return $query->post_count;

	}

	/**
	 * @param string|array|WPLib_Query $query
	 * @param array $args
	 *
	 * @return WPLib_Post_List_Default|KOAO_Agency[]
	 */
	static function get_agency_list( $query, $args = array() ) {

		$md5 = md5( serialize( array( $query, $args ) ) );
		$cache_key = "koao-agencies-list[{$md5}]";

		if ( ! ( $list = WPLib::cache_get( $cache_key ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => self::POSTS_PER_PAGE,
				'order'          => 'ASC',
				'orderby'        => 'title menu_order',
				'paged'          => 0,
			) );

			$args = wp_parse_args( $args, array(
				'agency_type_id' => null,
			));

			if ( $args['agency_type_id'] ) {

				$query[ KOAO::TAX_QUERY_KEY ] = array(
					array(
						'taxonomy' => KOAO_Agency_Type::TAXONOMY,
						'field'    => 'term_id',
						'terms'    => intval( $args['agency_type_id'] ),
					)
				);

			}
			unset( $args['agency_type_id'] );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			));

			$list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $list, null, 15 * 60 );

		}

		return $list;

	}

	/**
	 * Find a rate by specified agency type.
	 *
	 * This method is static and takes in all service rates as a parameter, because this way it is faster in a cycle.
	 *
	 * @param array $service_rates a non-indexed list of service rates
	 * @param $agency_type_term_id int
	 *
	 * @return int|float
	 */
	static function find_service_rate( $service_rates, $agency_type_term_id ) {

		do {

			$result = 0;

			if ( empty( $service_rates ) ) {
				break;
			}

			if ( 0 === absint( $agency_type_term_id )) {
				break;
			}

			foreach ( $service_rates as $rate ) {
				if ( isset( $rate[ 'term' ] ) && $rate[ 'term' ] === $agency_type_term_id ) {
					$result = $rate[ 'rate' ];
					break;
				}
			}

		} while ( false );

		return $result;

	}

}

KOAO_Agencies::on_load();

