<?php
/**
 * @var KOAO_Agency $agency
 */
?>
<style>
	.agency-fields .field {
		margin: 1em 0;
		display: block;
	}

	.agency-fields .label-text {
		display: block;
		font-weight: bold;
	}

	.agency-fields legend {
		font-size: 1.25em;
		font-weight: bold;
	}

	.agency-fields select {
		width: 100%;
		max-width:25em;
	}

	.agency-fields input[type="text"] {
		width: 100%;
		max-width:50em;
	}

</style>
<script>

jQuery(document).ready(function ($) {

	var $agency_types = $('#koao-agency-typechecklist');

	$agency_types.find('input[type="checkbox"]').on('change', function() {
		refresh_rates();
	});

	function refresh_rates() {

		var html = '';
		$agency_types.find('input[type="checkbox"]:checked').parent().each( function(idx, el) {
			html += '<tr><td>'+$(el).text()+'</td><td><input type="text"></td></tr>';

		});
		$('.agency_rates').find('tbody').empty().append( html );
	}

	refresh_rates();

});
</script>
<div class="agency-fields">

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Agency Name', 'koao-theme' ); ?></span>
		<input type="text" name="koao_agency[agency_name]" value="<?php $agency->the_agency_name_attr(); ?>">
	</label>

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Agency Subcategory', 'koao-theme' ); ?></span>
		<?php $curr = $agency->subcategory(); ?>
		<select name="koao_agency[subcategory]">
			<option <?php selected( $curr, '' );    ?> value=""><?php esc_html_e('', 'koao-theme'); ?></option>
			<option <?php selected( $curr, 'digital' ); ?> value="digital"><?php esc_html_e('Digital', 'koao-theme'); ?></option>
			<option <?php selected( $curr, 'traditional' ); ?> value="traditional"><?php esc_html_e('Traditional', 'koao-theme'); ?></option>
		</select>
	</label>

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Agreement Type', 'koao-theme' ); ?></span>
		<?php $curr = $agency->agreement_type(); ?>
		<select name="koao_agency[agreement_type]">
			<option <?php selected( $curr, '' );    ?> value=""><?php esc_html_e('', 'koao-theme'); ?></option>
			<option <?php selected( $curr, 'msa' ); ?> value="msa"><?php esc_html_e('MSA', 'koao-theme'); ?></option>
			<option <?php selected( $curr, 'sow' ); ?> value="sow"><?php esc_html_e('SOW', 'koao-theme'); ?></option>
			<option <?php selected( $curr, 'one' ); ?> value="msa"><?php esc_html_e('One-off', 'koao-theme'); ?></option>
		</select>
	</label>

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Agreement Start Date', 'koao-theme' ); ?></span>
		<input type="date" name="koao_agency[start_date]" value="<?php $agency->the_start_date_attr(); ?>">
	</label>

	<label class="field">
		<span class="label-text"><?php esc_html_e( 'Agreement End Date', 'koao-theme' ); ?></span>
		<input type="date" name="koao_agency[end_date]" value="<?php $agency->the_end_date_attr(); ?>">
	</label>

	<fieldset>

		<legend><?php esc_html_e( 'Office Address', 'koao-theme' ); ?></legend>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Street Address', 'koao-theme' ); ?></span>
			<input type="text" name="koao_agency[street_address]"
			       value="<?php $agency->the_street_address_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Address Line 2', 'koao-theme' ); ?></span>
			<input type="text" name="koao_agency[address_line_2]"
			       value="<?php $agency->the_address_line_2_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'City', 'koao-theme' ); ?></span>
			<input type="text" name="koao_agency[address_locality]"
			       value="<?php $agency->the_address_locality_attr(); ?>">
		</label>                           `

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'State', 'koao-theme' ); ?></span>
			<input type="text" name="koao_agency[address_region]"
			       value="<?php $agency->the_address_region_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Zip Code', 'koao-theme' ); ?></span>
			<input type="text" name="koao_agency[postal_code]"
			       value="<?php $agency->the_postal_code_attr(); ?>">
		</label>

	</fieldset>

	<fieldset>

		<legend><?php esc_html_e( 'Contact Information', 'koao-theme' ); ?></legend>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Contact Name', 'koao-theme' ); ?></span>
			<input type="text" name="koao_agency[contact_name]"
			       value="<?php $agency->the_contact_name_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Contact Email', 'koao-theme' ); ?></span>
			<input type="email" name="koao_agency[contact_email]"
			       value="<?php $agency->the_contact_email_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Office Phone', 'koao-theme' ); ?></span>
			<input type="tel" name="koao_agency[office_phone]"
			       value="<?php $agency->the_office_phone_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php esc_html_e( 'Web Address', 'koao-theme' ); ?></span>
			<input type="url" name="koao_agency[url]" value="<?php $agency->the_url_attr(); ?>">
		</label>

	</fieldset>

</div>