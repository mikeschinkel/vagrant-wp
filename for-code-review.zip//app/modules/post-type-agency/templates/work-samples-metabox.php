<?php
/**
 * @var $agency KOAO_Agency
 */
$work_samples = $agency->work_samples();

if ( count( $work_samples ) ) : ?>
	<br><ul>
	<?php foreach ( $work_samples as $work_sample ) :?>
		<li class="jq-work-sample">
		<div class="jq-magnific-popup mfp-hide">
		<?php
		WPLib::the_link(
			get_edit_post_link( $work_sample->ID() ),
			$work_sample->get_featured_image_html( 'thumbnail' ),
			'title=' . __('Click to edit', 'koao-theme')
		); ?>
		</div>
		</li>
	<?php endforeach; ?>
	</ul>
<?php endif; ?>

<br>

<?php
WPLib::the_link(
	admin_url('/post-new.php?post_type=koao-work-sample&agency=' . $agency->ID() ),
	__('Add work sample', 'koao-theme' ),
	'class=button'
);
