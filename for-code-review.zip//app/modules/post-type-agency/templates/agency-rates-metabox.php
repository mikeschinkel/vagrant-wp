<?php
/**
 * @var $agency KOAO_Agency
 */

?>
<script>
 jQuery(document).ready(function ($) {

	 var $rates_table = $('.agency-rates'),
		 $submit_rates = $('#submit-rates'),
		 $inputs = $rates_table.find('input.rate');

	 function prepare_rates() {
		 var $rates = $inputs.filter(function () {
			 //gel all non-empty and non-zero inputs
			 return !!this.value;
		 });

		 var result = [];
		 $rates.each(function(idx, input) {
			 var $rate = $(input),
				 $term = $rate.parent().prev().find('input');

			 if ( $term.is(':checked') && $.trim( $rate.val() ) ) {
				 result.push({
					 'term': $term.val(),
					 'rate': $.trim( $rate.val() )
				 });
			 }
		 });
		 $submit_rates.val( JSON.stringify( result ) );
	 }

	 $rates_table.find('input[type="checkbox"]').on('change', function() {
		 prepare_rates();
	 });

	 $inputs.on('change', function() {
		 prepare_rates();
	 });

	 prepare_rates();

 });
</script>
<style>
.agency-rates {
	width: 100%;
	max-width: 20em;
}
.agency-rates thead {
	font-weight: bold;
}
.agency-rates label {
	margin-right: 2em;
}

.agency-rates input {
	margin-right: 0.5em;
	text-align: right;
}
</style>
<input type="hidden" name="tax_input[koao-agency-type][]"  value="0" />
<input type="hidden" name="koao_agency[service_rates]" value="0" id="submit-rates" />
<table class="agency-rates">
	<thead>
		<tr>
			<td>
				<?php esc_html_e('Agency Type', 'koao-theme' ); ?>
			</td>
			<td><?php esc_html_e('Base Rate', 'koao-theme' ); ?></td>
		</tr>
	</thead>
	<tbody>

	<?php

	$all_types      = KOAO::agency_types_list();
	$rates          = $agency->service_rates();
	$assigned_types = array_keys( $agency->agency_type_names() );

	if ( count( $all_types )) :
		foreach ( $all_types as $type ) { ?>
			<tr><?php
				$term_id = $type->term_id();
				?>
				<td>
					<label>
						<?php
							printf('<input value="%d" %s name="tax_input[koao-agency-type][]" type="checkbox" />',
								$term_id,
								checked( in_array( $term_id, $assigned_types ), true, false )
							);
							esc_html_e( $type->term_name() );
						?>
					</label>
				</td>
				<td><?php
					/**
					 *
					 */
					printf('<input class="rate" size="5" value="%s" type="text" />',
						esc_attr( KOAO::find_service_rate( $rates, $term_id ))
					);
					?>
				</td>
			</tr> <?php
		}
	endif; ?>
	</tbody>
</table>
