<?php

/**
 * Class KOAO_Agency_Model
 * @method KOAO_Agency_View view()
 * @property KOAO_Agency_View $view
 */
class KOAO_Agency_Model extends WPLib_Post_Model_Base {

	function agency_name() {
		return $this->title();
	}

	function agreement_type() {
		return $this->get_meta_value( 'agreement_type' );
	}

	function subcategory() {
		return $this->get_meta_value( 'subcategory' );
	}

	function start_date() {
		return $this->get_meta_value( 'start_date' );
	}

	function end_date() {
		return $this->get_meta_value( 'end_date' );
	}

	function street_address() {
		return $this->get_meta_value( 'street_address' );
	}

	function address_line_2() {
		return $this->get_meta_value( 'address_line_2' );
	}

	function address_locality() {
		return $this->get_meta_value( 'address_locality' );
	}

	function address_region() {
		return $this->get_meta_value( 'address_region' );
	}

	function postal_code() {
		return $this->get_meta_value( 'postal_code' );
	}

	function contact_name() {
		return $this->get_meta_value( 'contact_name' );
	}

	function contact_email() {
		return $this->get_meta_value( 'contact_email' );
	}

	function office_phone() {
		return $this->get_meta_value( 'office_phone' );
	}

	function url() {
		return $this->get_meta_value( 'url' );
	}

	function permalink() {

		$permalink = '';
		if ( $this->has_post() ) {
			$permalink = get_the_permalink( $this->post() );
		}

		return $permalink;
	}

	/**
	 * @return WP_Term[]
	 */
	function agency_types() {

		$terms = array();

		if ( $this->has_post() ) {

			$terms = wp_get_object_terms( $this->ID(), KOAO_Agency_Type::TAXONOMY );

			if ( is_wp_error( $terms ) ) {
				$terms = array();
			}
		}

		return $terms;
	}


	/**
	 *
	 *
	 * @return array Names of assigned Agency Types, indexed by Agency Type term_id.
	 */
	function agency_type_names() {

		$result = array();

		if ( $this->has_post() ) {

			$terms = $this->agency_types();
			$result = wp_list_pluck( $terms, 'name', 'term_id' );

		}

		return $result;

	}


	/**
	 * @return WP_Term[]
	 */
	function authorized_services() {

		$terms = array();

		if ( $this->has_post() ) {

			$terms = wp_get_object_terms( $this->ID(), KOAO_Service_Type::TAXONOMY );
			if ( is_wp_error( $terms ) ) {
				$terms = array();
			}
		}

		return $terms;
	}


	/**
	 * @return array Names of assigned Service Types, indexed by Service Type term_id.
	 */
	function authorized_service_names() {

		$result = array();

		if ( $this->has_post() ) {

			$terms = $this->authorized_services();
			$result = wp_list_pluck( $terms, 'name', 'term_id' );

		}

		return $result;
	}

	/**
	 * Returns true if service rates exists for this agency
	 *
	 * @return bool
	 */
	function has_service_rates() {

		return !empty( $this->service_rates() );

	}

	/**
	 * @return array associative array of numerical values indexed by Agency Type term_id.
	 */
	function service_rates() {

		return (array) $this->get_meta_value( 'service_rates', array() );

	}

	/**
	 * Get associative array of URLs to download roster files from (indexed by Agency Type name).
	 *
	 * @return array download URLs, indexed by Agency Type name.
	 */
	function service_rate_urls() {

		do {

			$result = array();

			$types = $this->agency_type_names();

			foreach ( $this->service_rates() as $line ) {

				$term_id = $line['term'];
				if ( isset( $types[ $term_id ] ) ) {
					/**
					 * @future This is confusing.
					 *         The method is named "service_rate_urls"
					 *         but is a collection of "roster_file_url"s?
					 *         Explain?
					 */
					$result[ $types[ $term_id ] ] = KOAO::get_roster_file_url( $term_id, $this->ID() );
				}

			}

		} while ( false );

		return $result;

	}

	/**
	 * @param int $agency_type_id
	 *
	 * @return float zero if there is no rate for specified agency_type
	 */
	function get_service_rate( $agency_type_id ) {

		$rate = 0;

		if ( $agency_type_id ) {

			$rates  = $this->service_rates();

			$rate = KOAO::find_service_rate( $rates, absint( $agency_type_id ));
		}

		return $rate;
	}

	/**
	 * Get raw data for roster file.
	 *
	 * We put just raw data here -- fputcsv() will perform implode and escape as needed.
	 *
	 * @param $args
	 *
	 * @return array
	 */
	function get_roster_data( $args ) {

		if ( !$this->has_post() ) {
			return array();
		}

		$types  = $this->agency_type_names();

		$args = wp_parse_args( $args, array(
			'agency_type_id' => ''
		));

		$result = array(
			html_entity_decode( $this->agency_name() ),
			html_entity_decode( $types[ $args['agency_type_id'] ] ),
			$this->get_service_rate( $args['agency_type_id'] )
		);

		return $result;
	}

	/**
	 * @return bool
	 */
	function has_work_samples() {

		if ( !$this->has_post() ) {
			return false;
		}

		$query = new WPLib_Query( array(
			'posts_per_page' => 1,
			'post_type'      => KOAO_Work_Sample::POST_TYPE,
			'fields'         => 'ids',
			'post_parent'    => $this->ID()
		) );

		return 0 < $query->post_count;

	}

	/**
	 * @return KOAO_Work_Sample[]
	 */
	function work_samples() {

		/*
         * @todo Mike, should we try to return ALL items with such parameter-less methods?
		 * @todo Saru: Maybe in general, but not for Coke because 10up won't let us use
		 *             this method because they will not allow an unconstrained query.
		 *             See what I changed it too.
		 *
		 */

		return $this->get_work_samples( 'posts_per_page=' . WPLib::max_posts_per_page() );

	}

	/**
	 * @param array $query
	 * @param array $args
	 *
	 * @return KOAO_Work_Sample[]
	 */
	function get_work_samples( $query, $args = array() ) {

		$result = array();

		if ( $this->has_post() ) {

			$query = wp_parse_args( $query, array(
				'posts_per_page' => 5,
				'post_parent'    => $this->ID(),
				'post_type'      => KOAO_Work_Sample::POST_TYPE
			));

			$args = wp_parse_args( $args, array(
				'list_owner' => 'KOAO_Work_Samples'
			));

			$result = WPLib_Posts::get_list( $query, $args );
		}

		return $result;
	}

	/**
	 * Sanitize and update stored agency rates.
	 *
	 * @param $agency_rates
	 *
	 * @return bool true if succeeded, false otherwise
	 */
	function update_agency_rates( $agency_rates ) {

		$clean = array();

		do {

			if ( empty( $agency_rates ) ) {
				break;
			}

			$agency_rates = json_decode( $agency_rates, true );

			if ( empty( $agency_rates ) ) {
				break;
			}

			foreach ( $agency_rates as $item ) {
				/*
				 * expecting an array of floating point numbers, indexed by agency_type->term_id
				 */
				if ( ! isset( $item[ 'term' ] ) || ! absint( $item[ 'term' ] ) ) {
					continue;
				}
				if ( ! isset( $item[ 'rate' ] ) || ! is_numeric( $item[ 'rate' ] ) ) {
					continue;
				}

				/*
				 * We will have to query post meta using LIKE expression, therefore we need some extra markup.
				 * That's why we store this field as a javascript-like associative array, rather than just rates indexed by term.
				 */
				$clean[] = array(
					'term' => absint( $item[ 'term' ] ),
					'rate' => round( floatval( absint( $item[ 'rate' ] ) ), 2 )
				);
			}
		} while ( false );

		/**
		 * Note, this was just sanitized, therefore we will skip further sanitization by specifying 'raw' sanitizer.
		 */
		return KOAO::update_post_meta( $this->ID(), 'service_rates', $clean, $sanitizer = 'raw' );
	}

}
