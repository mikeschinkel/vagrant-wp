<?php

/**
 * KOAO_Agency
 *
 * @property KOAO_Agency_Model $model
 * @property KOAO_Agency_View $view
 *
 * @mixin KOAO_Agency_Model
 * @mixin KOAO_Agency_View
 *
 */
class KOAO_Agency extends WPLib_Post_Base {

	const POST_TYPE = KOAO_Agencies::POST_TYPE;
	const VAR_NAME = 'agency';

}