<?php

/**
 * Class KOAO_Agency_View
 *
 * @mixin KOAO_Agency
 *
 * @property KOAO_Agency $item
 * @property KOAO_Agency_Model $model
 *
 * @method KOAO_Agency_Model model()
 * @method string the_agency_name_html()
 * @method string the_subcategory_html()
 * @method string the_contact_name_html()
 * @method string the_contact_email_html()
 * @method string the_office_phone_html()
 * @method string the_agreement_type_html()
 * @method string the_start_date_html()
 * @method string the_end_date_html()
 *
 * @method void the_agency_name()
 * @method void the_agency_type()
 * @method void the_subcategory()
 * @method void the_contact_name()
 * @method void the_contact_email()
 * @method void the_address_html()
 * @method void the_office_phone()
 * @method void the_start_date()
 * @method void the_end_date()
 * @method void the_street_address()
 * @method void the_address_line_2()
 * @method void the_address_locality()
 * @method void the_address_region()
 * @method void the_postal_code()
 *
 * @method void the_agency_name_attr()
 * @method void the_agency_type_attr()
 * @method void the_subcategory_attr()
 * @method void the_contact_name_attr()
 * @method void the_contact_email_attr()
 * @method void the_address_html_attr()
 * @method void the_office_phone_attr()
 * @method void the_start_date_attr()
 * @method void the_end_date_attr()
 * @method void the_street_address_attr()
 * @method void the_address_line_2_attr()
 * @method void the_address_locality_attr()
 * @method void the_address_region_attr()
 * @method void the_postal_code_attr()
 * @method void the_agency_types_html()
 * @method void the_authorized_services_html( $args = array() )
 */
class KOAO_Agency_View extends WPLib_Post_View_Base {

	/**
	 * @return string
	 */
	function get_agency_types_html() {

		$model = $this->model();

		if ( ! $model->has_post() ) {
			return '';
		}

		$types = array_values( $model->agency_type_names() );

		return !empty( $types )
			? implode( ', ', $types )
			: '&mdash;';

	}

	/**
	 * @return string
	 */
	function get_authorized_services_html() {

		$model = $this->model();

		if ( ! $model->has_post() ) {
			return '';
		}

		$services = array_values( $model->authorized_service_names() );

		return !empty( $services )
			? implode( ', ', $services )
			: '&mdash;';

	}

	/**
	 * @param string $size
	 * @param array $args {
	 *
	 *      @type string $height height for person icon, to be presented when featured image is not set.
	 *      @type string $width width for person icon, to be presented when featured image is not set.
	 *
	 * }
	 */
	function the_featured_image_html( $size = 'post-thumbnail', $args = array() ) {

		if ( ! $this->has_post() ) {
			return '';
		}

		if ( $this->has_featured_image() ) {
			echo $this->get_featured_image_html( $size, "title={$this->get_agency_name_attr()}" );
		} else {

			$args = wp_parse_args( $args, array(
				'height' => '100px',
				'width'  => '100px'
			));

			WPLib::the_img(
				KOAO::get_themeable_asset_url( 'agency-icon' ),
				sprintf('height=%s&width=%s&title=%s', $args['height'], $args['width'], $this->get_agency_name_attr() )
			);
		}
	}

	/**
	 * @return string|void
	 */
	function get_agency_name_attr() {

		return esc_attr( $this->agency_name() );

	}
}
