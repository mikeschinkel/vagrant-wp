<?php

/**
 * Class KOAO_Work_Sample_Model
 */
class KOAO_Work_Sample_Model extends WPLib_Post_Model_Base {

	/**
	 * @return int
	 */
	function agency_id() {
		return $this->parent_id();
	}

	/**
	 * @return string
	 */
	function description() {
		return $this->content();
	}

	/**
	 * @return string
	 */
	function date() {
		return $this->get_meta_value( 'date' );
	}

	/**
	 * Get the list of attachments associated with this Work Sample.
	 *
	 * @param array $args
	 *
	 * @return WP_Post[]
	 */
	function attachments( $args = array() ) {

		$attachments = array();

		if ( $this->has_post() ) {

			$args = wp_parse_args( $args, array(
				'posts_per_page' => 50,
				'order'          => 'ASC',
				'post_mime_type' => 'image',
				'post_parent'    => $this->ID(),
				'post_status'    => 'any',
				'post_type'      => 'attachment',
			) );
			$attachments = get_children( $args );
		}

		return $attachments;
	}

}
