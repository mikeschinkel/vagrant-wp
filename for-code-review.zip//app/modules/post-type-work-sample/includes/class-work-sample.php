<?php

/**
 * KOAO_Work_Sample
 *
 * @property KOAO_Work_Sample_Model $model
 * @property KOAO_Work_Sample_View $view
 * @mixin KOAO_Work_Sample_Model
 * @mixin KOAO_Work_Sample_View
 *
 */
class KOAO_Work_Sample extends WPLib_Post_Base {

	const POST_TYPE = KOAO_Work_Samples::POST_TYPE;
	const VAR_NAME = 'work_sample';

}