<?php

/**
 * Class KOAO_Work_Sample_View
 *
 * @property KOAO_Work_Sample $item
 * @property KOAO_Work_Sample_Model $model
 *
 * @method KOAO_Work_Sample_Model model()
 * @method void the_title_attr()
 * @method void the_date_attr()
 * @mixin KOAO_Work_Sample
 */
class KOAO_Work_Sample_View extends WPLib_Post_View_Base {

	/**
	 * @param string $size
	 *  @param array $args {
	 *   	@type string $title
	 *   	@type string $height
	 *   	@type string $width
	 * }
	 */
	function the_featured_image_html( $size = 'post-thumbnail', $args = array() ) {

		$model = $this->model();

		$args = wp_parse_args( $args, array(
			'title'  => $model->title(),
			'height' => '100px',
			'width'  => '100px'
		));

		if ( $model->has_featured_image() ) {

			parent::the_featured_image_html( $size, $args );

		} else {

			/*
			 * @todo Restructure so file path can be registered in functions.php
			 */
			KOAO::the_img( KOAO::get_asset_url( 'images/icon-resource-type-form.svg', 'KOAO_Theme' ), $args );

		}

	}

	/**
	 *  @param array $args {
	 *   	@type string $size
	 *   	@type string $class_li
	 *   	@type string $before
	 *   	@type string $after
	 *   	@type string $template
	 *   	@type string $before_li
	 *   	@type string $after_li
	 * }
	 */
	function the_attached_images_html( $args = array() ) {

		echo $this->get_attached_images_html( $args );

	}

	/**
	 *  @param $args {
	 *   	@type string $size
	 *   	@type string $class_li
	 *   	@type string $before
	 *   	@type string $after
	 *   	@type string $template
	 *   	@type string $before_li
	 *   	@type string $after_li
	 * }
	 * @return string
	 */
	function get_attached_images_html( $args = array() ) {

		$args = wp_parse_args( $args, array(
			'size'      => 'full',
			'class_li'  => '',
			'before'    => '',
			'after'     => '',
			'template'  => '<a %1$s href="%2$s">%3$s</a>',
			'before_li' => '',
			'after_li'  => '',
		));

		$attachments = $this->model()->attachments();

		$html = '';

		if ( !empty( $attachments ) ) {
			$items = array();
			foreach ( $attachments as $attachment ) {
				$image_attributes = wp_get_attachment_image_src( $attachment->ID, $args[ 'size' ] );
				if ( !empty( $image_attributes ) ) {
					$items[] = sprintf( $args['template'],
						trim( $args[ 'class_li' ] )
							? 'class="' . esc_attr( $args[ 'class_li' ] ) . '"'
							: '',
						$image_attributes[ 0 ],
						esc_attr( $image_attributes[ 0 ] )
					);
				}
			}
			if ( !empty( $items ) ) {
				$html = $args['before'] .
				            $args['before_li'] .
				                implode( $args['after_li'] . $args['before_li'], $items ) .
				            $args['after_li'] .
				        $args['after'];
			}
		}

		return $html;
	}

}
