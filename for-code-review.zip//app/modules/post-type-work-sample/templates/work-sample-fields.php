<?php
/**
 * @var KOAO_Work_Sample $work_sample
 */
?>
<style>
	.work-sample-fields .field {
		margin: 1em 0;
		display: block;
	}

	.work-sample-fields .label-text {
		display: block;
		font-weight: bold;
	}

	.work-sample-fields legend {
		font-size: 1.25em;
		font-weight: bold;
	}

	#attachments li {
		display: inline-block;
		padding: 3px 4px 0 4px;
		border: 1px solid silver;
		margin: 0 10px 10px 0;
	}

	#attachments img {
		margin: 0;
		padding: 0;
	}
</style>
<script>
/*jQuery(document).ready(function ($) {
	$('.jq-thumb').on('click', function() {
		var selection = frame.state().get('selection');
		ids = jQuery('#my_field_id').val().split(',');
		ids.forEach(function(id) {
			attachment = wp.media.attachment(id);
			attachment.fetch();
			selection.add( attachment ? [ attachment ] : [] );
		});
	});
});*/
</script>
<div class="work-sample-fields">

	<label class="field">
		<span class="label-text"><?php _e( 'Agency', 'koao-theme' ); ?></span>
		<?
		$curr = $work_sample->agency_id();
		$curr = $curr !== 0 ? $curr : (isset( $_GET['agency'] ) ? absint( $_GET['agency'] ) : 0);
		if ( $curr ) {
			$agency = new KOAO_Agency( $curr );
		} ?>
		<input type="text"  readonly="readonly" size="40" value="<?php echo $curr ? $agency->get_agency_name_attr() : ''; ?>">
		<input type="hidden" name="koao_work_sample[agency_id]" value="<?php esc_attr_e( $curr ); ?>">
		<?php $agency->the_edit_link(); ?>
	</label>

	<fieldset>

		<legend><?php _e( 'Details', 'koao-theme' ); ?></legend>

		<label class="field">
			<span class="label-text"><?php _e( 'Work Title', 'koao-theme' ); ?></span>
			<input size="40" type="text" name="koao_work_sample[project]"
				value="<?php $work_sample->the_title_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php _e( 'Work Date', 'koao-theme' ); ?></span>
			<input size="20" type="date" name="koao_work_sample[date]"
				value="<?php $work_sample->the_date_attr(); ?>">
		</label>

		<label class="field">
			<span class="label-text"><?php _e( 'Work Description', 'koao-theme' ); ?></span>
			<textarea cols="40" rows="5" name="koao_work_sample[description]"><?php echo esc_textarea( $work_sample->description() ); ?></textarea>
		</label>

	</fieldset>

</div>
