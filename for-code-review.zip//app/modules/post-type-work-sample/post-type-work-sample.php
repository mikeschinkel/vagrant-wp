<?php

/**
 * Class KOAO_Work_Samples
 */
class KOAO_Work_Samples extends WPLib_Post_Module_Base {

	const POST_TYPE      = 'koao-work-sample';
	const MODULE_NAME    = 'post-type-work-sample';
	const INSTANCE_CLASS = 'KOAO_Work_Sample';

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'Work Samples', 'koao-theme' ),
			'singular_name' => __( 'Work Sample', 'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'Work Samples', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => false,
			'menu_icon'    => 'dashicons-id',
			'hierarchical' => false,
			'supports'     => array(
				'thumbnail',
				'page-attributes'
			),
		) );

		/**
		 * Edit fields
		 */
		self::add_class_action( 'edit_form_after_title' );
		self::add_class_action( 'wp_insert_post_data' );
		self::add_class_action( 'save_post' );

		self::add_class_action( 'do_meta_boxes' );

	}

	static function _do_meta_boxes() {

		//remove_meta_box( 'postimagediv', self::POST_TYPE . '_image_box', 'side' );
		add_meta_box( 'attachments', __( 'Attached Images', 'koao-theme' ), array( __CLASS__, 'attachments_meta_box'), self::POST_TYPE, 'normal', 'high' );
	}

	static function attachments_meta_box() {
		global $post;

		$work_sample = new KOAO_Work_Sample( $post );
		$args = array(
			'size'      => 'thumbnail',
			'class_li'  => '',
			'before'    => '<ul>',
			'after'     => '</ul>',
			'template'  => '<img %1$s src="%2$s" alt="%3$s" >',
			'before_li' => '<li class="jq-thumb">',
			'after_li'  => '</li>',
		);
		$work_sample->the_attached_images_html( $args );

	}

	/**
	 * @param WP_Post $post
	 */
	static function _edit_form_after_title( $post ) {

		if ( self::POST_TYPE === $post->post_type ) {
		?>
			<div id="work-sample-after-title" class="postbox">
				<div class="handlediv" title="<?php esc_attr_e( 'Click to toggle', 'koao-theme' ); ?>"><br></div>
					<h3 class="hndle"><span><?php esc_attr_e( 'Project Details', 'koao-theme' ); ?></span></h3>
					<div class="inside">
					<?php

						$work_sample = new KOAO_Work_Sample( $post );
						$work_sample->the_template( 'work-sample-fields' );
						wp_nonce_field( '_work_sample_meta_nonce', 'work_sample_nonce' );

					?>
				</div>
			</div>
        <?php
		}
	}

	/**
	 * Assign post_title and post_parent from meta.
	 *
	 * @param array $data
	 * @param array $postarr
	 *
	 * @return array
	 */
	static function _wp_insert_post_data( $data, $postarr ) {

		if ( self::POST_TYPE === $data['post_type'] ) {

			$group = KOAO::short_prefix() . self::var_name();

			if ( isset( $postarr[ $group ], $postarr[ $group ]['project'] ) ) {
				$data['post_title']   = $postarr[ $group ]['project'];
			}
			if ( isset( $postarr[ $group ], $postarr[ $group ]['agency_id'] ) ) {
				$data['post_parent']  = $postarr[ $group ]['agency_id'];
			}
			if ( isset( $postarr[ $group ], $postarr[ $group ]['description'] ) ) {
				$data['post_content'] = $postarr[ $group ]['description'];
			}

		}

		return $data;
	}

	/**
	 * @param int $post_id
	 */
	static function _save_post( $post_id ) {

		do {

			if ( self::POST_TYPE !== get_post_type( $post_id ) ) {
				break;
			}

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				break;
			}

			if ( ! wp_verify_nonce( KOAO::get_http_POST( 'work_sample_nonce' ), '_work_sample_meta_nonce' ) ) {
				break;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				break;
			}

			KOAO::update_post_meta_from_POST( $post_id,
				KOAO::short_prefix() . self::var_name(),
				array(
					'agency_id'   => 'int',
					'title'       => 'text',
					'description' => 'text',
					'date'        => 'text',
				)
			);

		} while ( false );

	}

	/**
	 * @return KOAO_Person[]
	 */
	static function work_samples_list() {

		return self::get_work_samples_list( array() );

	}

	/**
	 * @param string|array|WPLib_Query $query
	 * @param array $args
	 *
	 * @return WPLib_Post_List_Base
	 */
	static function get_work_samples_list( $query, $args = array() ) {

		$md5  = md5( serialize( array( $query, $args ) ) );
		$cache_key = "koao-work-samples-list[{$md5}]";

		if ( ! ( $list = WPLib::cache_get( $cache_key ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 12,
				'order'          => 'ASC',
				'orderby'        => 'title menu_order',
			) );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			) );

			$list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $list, null, 15 * 60 );

		}

		return $list;

	}

}

KOAO_Work_Samples::on_load();


