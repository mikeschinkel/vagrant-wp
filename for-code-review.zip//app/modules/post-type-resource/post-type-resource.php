<?php

/**
 * Class KOAO_Resources
 */
class KOAO_Resources extends WPLib_Post_Module_Base {

	const POST_TYPE      = 'koao-resource';
	const MODULE_NAME    = 'post-type-resource';
	const INSTANCE_CLASS = 'KOAO_Resource';

	static function on_load() {

		KOAO::register_helper( __CLASS__ );

		$labels = self::register_post_type_labels( array(
			'name'          => __( 'Resources', 'koao-theme' ),
			'singular_name' => __( 'Resource', 'koao-theme' ),
			'all_items'     => __( 'Resources', 'koao-theme' ),
		) );

		self::register_post_type( array(
			'label'        => __( 'Resources', 'koao-theme' ),
			'labels'       => $labels,
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => KOAO::RESOURCES_MENU_SLUG,
			'menu_icon'    => 'dashicons-media-default',
			'hierarchical' => false,
			'supports'     => array(
				'page-attributes',
			),
		) );

		/*
		 * Enable meta fields
		 */
		//Add meta field controls
		self::add_class_action( 'edit_form_after_title' );
		//Persist meta field values to the DB
		self::add_class_action( 'save_post' );
		//Map some of the meta field inputs to standard post fields
		self::add_class_action( 'wp_insert_post_data' );

		/*
		 * Enqueue admin scripts and styles
		 */
		self::add_class_action( 'admin_enqueue_scripts' );

		/*
		 * "Manually" adding Admin menu in order to have better control of its subitems.
		 */
		self::add_class_action( 'admin_menu');

		/*
		 * Make sure Resources top level menu is highlighted when looking at Resource Types page
		 */
		self::add_class_action('parent_file');

		/*
		 * Add HTML for [Add New {Subtype}]
		 */
		self::add_class_action( 'admin_footer' );

		/*
		 * Admin list columns
		 */
		$post_type = self::POST_TYPE;

		self::add_class_filter("manage_edit-{$post_type}_columns");
		self::add_class_filter("manage_{$post_type}_posts_custom_column");
		self::add_class_filter("manage_edit-{$post_type}_sortable_columns");
		self::add_class_filter("request");


	}

	static function _admin_enqueue_scripts( $hook ) {

		$screen = WPLib::current_screen();

		if ( isset( $screen->post_type ) && self::POST_TYPE === $screen->post_type ) {

			wp_enqueue_media();

			wp_enqueue_style(  'resources-admin', WPLib::get_asset_url( '/css/resources-admin.css', __CLASS__ ) );
			wp_enqueue_script( 'resources-admin', WPLib::get_asset_url( '/js/resources-admin.js', __CLASS__ ), array( 'jquery' ) );
		}
	}

	static function _admin_menu() {

		$title = __( 'Resources', 'koao-theme' );
		add_menu_page(
			$title,
			$title,
			'edit_posts',
			KOAO::RESOURCES_MENU_SLUG,
			'',
			'dashicons-archive',
			25
		);
	}

	/**
	 * @param WP_Post $post
	 */
	static function _edit_form_after_title( $post ) {

		if ( self::POST_TYPE !== $post->post_type ) {
			return;
		} ?>

		<?php

		/*
		 * Definition contains a list of fields that conform to KOAO form schema.
		 */
		$definition = self::get_resource_type_definition();

		?>

		<div id="resource-after-title" class="postbox">
			<div class="handlediv" title="<?php esc_html_e( 'Click to toggle', 'koao-theme' ); ?>"><br></div>
			<h3 class="hndle">
				<span><?php
					esc_html_e(
						sprintf( _x('%s Details', 'Resource Type details', 'koao-theme'),
							$definition['resource_type']['label']
						)
					); ?>
				</span></h3>
			<div class="inside">
				<?php

				$screen = WPLib::current_screen();

				$form_args = array();
				if ('add' === $screen->action ) {
					/*
					 * Add New Resource
					 */
					$form_args['passed_values'] = array();
					foreach ( $definition as $field_name => $field ) {
						/**
						 * Clean up the values that are passed as query parameters
						 */
						if ( isset( $_GET[ $field_name ]) && ( $clean = KOAO::sanitize_meta( $_GET[ $field_name ], $field['sanitizer'] ) )) {
							$form_args['passed_values'][ $field_name ] = $clean;
						}
					}

					/*
					 * Make sure a proper resource_type is specified
					 */
					if (    ! isset( $form_args['passed_values']['resource_type'] )
					    || ! self::is_supported_resource_type( $form_args['passed_values']['resource_type'] )
					) {
						$form_args['passed_values']['resource_type'] = self::get_resource_type();
					}

					$form_args['is_fully_sanitized'] = true;

				} else {
					/*
					 * Edit Resource
					 */
					$form_args['entry'] = new KOAO_Resource( $post );
		        }

				$form_name = KOAO::short_prefix() . self::var_name(); /* 'koao_resource' */;

				echo KOAO::get_form_contents( $form_name, $definition, $form_args );

				wp_nonce_field( '_resource_meta_nonce', 'resource_nonce' );

				?>
			</div>
		</div> <?php

	}

	/**
	 * Customize the post title
	 *
	 * @param array $data
	 * @param array $postarr
	 *
	 * @return array
	 */
	static function _wp_insert_post_data( $data, $postarr ) {

		if ( $data['post_type'] === self::POST_TYPE ) {
			$group = KOAO::short_prefix() . self::var_name();
			if ( isset( $postarr[ $group ], $postarr[ $group ]['title'] ) ) {
				$data['post_title']   = $postarr[ $group ]['title'];
			}
			if ( isset( $postarr[ $group ], $postarr[ $group ]['description'] ) ) {
				$data['post_content'] = $postarr[ $group ]['description'];
			}
		}

		return $data;
	}

	/**
	 * @param $post_id
	 */
	static function _save_post( $post_id ) {

		do {

			if ( self::POST_TYPE !== get_post_type( $post_id ) ) {
				break;
			}

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				break;
			}

			if ( ! wp_verify_nonce( KOAO::get_http_POST( 'resource_nonce' ), '_resource_meta_nonce' ) ) {
				break;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				break;
			}

			$form_name = KOAO::short_prefix() . self::var_name();

			if ( false === ( $http_form = KOAO::get_http_POST( $form_name, false ) ) ) {
				break;
			}

			$resource_type = sanitize_key( $http_form['resource_type'] );

			KOAO::update_post_meta_from_POST( $post_id,
				$form_name,
				KOAO::get_form_sanitizers( self::get_resource_type_definition( $resource_type ) )
			);

		} while ( false );

	}

	/**
	 * @return KOAO_Resource[]
	 */
	static function resources_list() {

		return self::get_resources_list();

	}

	/**
	 * @param array $query
	 * @param array $args
	 *
	 * @return KOAO_Resource[]
	 */
	static function get_resources_list( $query = array(), $args = array() ) {

		$args = wp_parse_args( $args, array(
			'show_protected' => KOAO::current_user_can_read_protected_resources()
		) );

		$md5 = md5( serialize( array( $query, $args ) ) );

		if ( ! ( $list = WPLib::cache_get( $cache_key = "koao-resource-list[{$md5}]" ) ) ) {

			$query = wp_parse_args( $query, array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'order'          => 'ASC',
				'orderby'        => 'title menu_order',
			) );

			$args = wp_parse_args( $args, array(
				'list_owner' => __CLASS__
			) );

			if ( ! $args['show_protected'] ) {
				/*
				 * be sure to skip all resources that are associated with protected terms.
				 */
				$protected_terms = KOAO_Resource_Types::get_list(array(
					'show_protected' => true,
					'protected_only' => true,
				));
				$term_ids = wp_list_pluck( $protected_terms, 'term_id' );

				$query[ KOAO::TAX_QUERY_KEY ] = array(
					array(
						'taxonomy' => KOAO_Resource_Types::TAXONOMY,
						'terms'    => $term_ids,
						'field'    => 'term_id',
						'operator' => 'NOT IN',
					),
				);

			}

			$list = WPLib_Posts::get_list( $query, $args );

			/*
			 * Expire in 15 minutes
			 */
			WPLib::cache_set( $cache_key, $list, null, 15 * 60 );

		}

		return $list;

	}

	static function resource_types() {

		static $resource_types;

		if ( is_null( $resource_types )) {
			$defaults = array(

				'document' => array(
					'resource_type' => array(
						'label'     => __( 'Document', 'koao-theme' ),
						'sanitizer' => 'text',
						'type'      => 'hidden',
						'input'     => 'hidden'
					),
					'title'         => array(
						'label'     => __( 'Document Title', 'koao-theme' ),
						'sanitizer' => 'text',
						'type'      => 'text'
					),
					'resource_url' => array(
						'label'     => __( 'Attachment', 'koao-theme' ),
						'sanitizer' => 'url',
						'type'      => 'text'
					),
					'attachment_id' => array(
						'label'     => __( 'Upload / Add Document', 'koao-theme' ),
						'sanitizer' => 'int',
						'type'      => 'media'
					),
					'description'   => array(
						'label'     => __( 'Description', 'koao-theme' ),
						'sanitizer' => 'html',
						'type'      => 'editor'
					),
				),
				'form'     => array(
					'resource_type' => array(
						'label'     => __( 'Form', 'koao-theme' ),
						'sanitizer' => 'text',
						'type'      => 'hidden',
						'input'     => 'hidden'
					),
					'title'         => array(
						'label'     => __( 'Form Title', 'koao-theme' ),
						'sanitizer' => 'text',
						'type'      => 'text'
					),
					'resource_url' => array(
						'label'     => __( 'Attachment', 'koao-theme' ),
						'sanitizer' => 'url',
						'type'      => 'text'
					),
					'attachment_id' => array(
						'label'     => __( 'Upload / Add Form', 'koao-theme' ),
						'sanitizer' => 'int',
						'type'      => 'media'
					),
					'description'   => array(
						'label'     => __( 'Description', 'koao-theme' ),
						'sanitizer' => 'html',
						'type'      => 'editor'
					),
				),
				'link'     => array(
					'resource_type' => array(
						'label'     => __( 'Link', 'koao-theme' ),
						'sanitizer' => 'text',
						'type'      => 'hidden',
						'input'     => 'hidden'

					),
					'title'         => array(
						'label'     => __( 'Link Title', 'koao-theme' ),
						'sanitizer' => 'text',
						'type'      => 'text'
					),
					'resource_url' => array(
						'label'     => __( 'URL', 'koao-theme' ),
						'sanitizer' => 'url',
						'type'      => 'url'
					),
					'description'   => array(
						'label'     => __( 'Description', 'koao-theme' ),
						'sanitizer' => 'html',
						'type'      => 'editor'
					),
				)
			);

			$resource_types = apply_filters( 'koao_resource_types', $defaults );
		}

		return $resource_types;
	}

	/**
	 * @param $resource_type string|null
	 *
	 * @return bool
	 */
	static function is_supported_resource_type( $resource_type ) {

		return $resource_type ? isset( self::resource_types()[ $resource_type ] ) : false;

	}

	/**
	 * Get current/default resource type.
	 *
	 *
	 * @param string|null $resource_type If not specified, parameter value is taken from $_GET.
	 *
	 * @return array
	 */
	static function get_resource_type( $resource_type = null ) {

		static $current_type;

		if ( ! $resource_type ) {
			$resource_type = sanitize_key( KOAO::get_http_GET( 'resource_type', 'document' ) );
		}

		if ( is_null( $current_type ) || $current_type !== $resource_type ) {
			$current_type = self::is_supported_resource_type( $resource_type )
				? $resource_type
				: 'document';
		}

		return $current_type;

	}

	/**
	 * @param string|null $resource_type
	 *
	 * @return array
	 */
	static function get_resource_type_definition( $resource_type = null ) {

		if ( ! self::is_supported_resource_type( $resource_type ) ) {
			$resource_type = self::get_resource_type();
		}

		return self::resource_types()[ $resource_type ];

	}


	/*
	 * Make sure Resources top level menu is highlighted when looking at Resource Types page
	 */
	static function _parent_file( $parent_file ) {

		global $current_screen; //$submenu_file;

		if ( self::POST_TYPE === $current_screen->post_type ) {

			//TODO: Code Sniffer does not allow this, but this is not critical, therefore -- comment out
			//if ( 'post-new.php' === $pagenow ) {
			//	$submenu_file = 'edit.php?post_type=' . self::POST_TYPE;
			//}

			$parent_file = KOAO::RESOURCES_MENU_SLUG;
		}

		return $parent_file;
	}


	static function _admin_footer() {

		$screen = WPLib::current_screen();

		if ( !isset( $screen->post_type ) && self::POST_TYPE === $screen->post_type ) {
			return;
		}

		$post_type_object = get_post_type_object( self::POST_TYPE );

		if ( current_user_can( $post_type_object->cap->create_posts ) ) {

			$post_new_file = "post-new.php?post_type=".self::POST_TYPE.'&resource_type=';

			echo '<div id="koao-extra-buttons" class="hidden">';
			foreach ( self::resource_types() as $subtype => $config ) {

				printf( ' <a href="%s" class="page-title-action extra">%s</a>',
					esc_url( admin_url( $post_new_file . $subtype ) ),
					sprintf( esc_html__('Add New %s', 'koao-theme'), $config['resource_type']['label'] )
				);

			}
			echo '</div>';
		}
	}

	/*
	 *
	 * Campaigns admin list functions
	 *
	 */
	static function _manage_edit_koao_resource_columns( $columns ) {
		/*
		 * note, extra column keys must correspond to field names
         */
		$new_columns = array(
			'cb'             => $columns['cb'],
			'title'          => $columns['title'],
			'resource_type'  => __('Resource', 'koao-theme'),
		);

		unset( $columns['cb'] );
		//unset( $columns['title'] );
		//unset( $columns['date'] );

		return array_merge( $new_columns, $columns );
	}

	/**
	 * @param string $column
	 */
	static function _manage_koao_resource_posts_custom_column( $column ) {
		global $post;

		if ( preg_match( '#^(resource_type)$#', $column ) ) {

			$resource = new KOAO_Resource( $post );
			if ( 'resource_type' === $column ) {
				esc_html_e( $resource->resource_type() );
			}

		}
	}

	static function _manage_edit_koao_resource_sortable_columns( $columns ) {

		$columns['resource_type']  = 'resource_type';

		return $columns;
	}

	/**
	 * Add params to enable campaign sorting by From and Until.
	 *
	 * @param array $vars
	 * @return array
	 */
	static function _request( $vars ) {

		do {
			if ( !isset( $vars['post_type'] ) || self::POST_TYPE !== $vars['post_type'] ) {
				break;
			}

			/*
			 * Modify sort order, maybe
			 */
			if ( isset( $vars['orderby'] ) && 'resource_type' !== $vars['orderby'] ) {

				/* Merge the query vars with our custom variables. */
				$vars = array_merge(
					$vars,
					array(
						KOAO::META_KEY_KEY => KOAO::_get_raw_meta_fieldname( 'resource_type' ),
						'orderby'  => 'meta_value'
					)
				);
			}

			/*
			 * Limit the list to non-protected resources, maybe
			 */
			if ( ! KOAO::current_user_can_read_protected_resources() ) {

				/*
				 * be sure to skip all resources that are associated with protected terms.
				 */
				$protected_terms = KOAO::get_resource_types( array(), array(
					'show_protected' => true,
					'protected_only' => true,
				));
				$term_ids = wp_list_pluck( $protected_terms, 'term_id' );

				$vars[ KOAO::TAX_QUERY_KEY ] = array(
					array(
						'taxonomy' => KOAO_Resource_Types::TAXONOMY,
						'terms'    => $term_ids,
						'field'    => 'term_id',
						'operator' => 'NOT IN',
					),
				);

			}

		} while ( false );

		return $vars;
	}

}
KOAO_Resources::on_load();
