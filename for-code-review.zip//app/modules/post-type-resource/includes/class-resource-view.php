<?php

/**
 * Class KOAO_Resource_View
 *
 * @mixin KOAO_Resource
 *
 * @property KOAO_Resource $item
 * @property KOAO_Resource_Model $model
 *
 * @method KOAO_Resource_Model model()
 *
 * @method void the_title()
 * @method void the_resource_url()
 * @method void the_attachment_id()
 * @method void the_resource_type()
 *
 * @method void the_title_attr()
 * @method void the_resource_url_attr()
 * @method void the_resource_type_attr()
 * @method void the_attachment_id_attr()
 *
 */
class KOAO_Resource_View extends WPLib_Post_View_Base {

	/**
	 * @param string $size
	 * @param array $args
	 */
	function the_featured_image_html( $size = 'post-thumbnail', $args = array() ) {

		switch ( $this->resource_type() ) {

			case 'document':
				$asset = "{$this->file_type()}-file-type-icon";
				break;

			case 'form':
				$asset = "form-resource-type-icon";
				break;

			case 'link':
				$asset = "link-resource-type-icon";
				break;

			default:
				$asset = "generic-resource-type-icon";
		}

		WPLib::the_img(
			KOAO::get_themeable_asset_url( $asset ),
			$args
		);

	}

}
