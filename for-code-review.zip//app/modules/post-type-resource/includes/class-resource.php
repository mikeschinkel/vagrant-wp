<?php

/**
 * KOAO_Resource
 *
 * @property KOAO_Resource_Model $model
 * @property KOAO_Resource_View $view
 * @mixin KOAO_Resource_Model
 * @mixin KOAO_Resource_View
 *
 */
class KOAO_Resource extends WPLib_Post_Base {

	const POST_TYPE = KOAO_Resources::POST_TYPE;
	const VAR_NAME  = 'resource';

}