<?php

/**
 * Class KOAO_Resource_Model
 *
 * @method KOAO_Resource_View view()
 * @property KOAO_Resource_View $view
 */
class KOAO_Resource_Model extends WPLib_Post_Model_Base {

	function resource_type() {
		return $this->get_meta_value( 'resource_type', 'document' );
	}

	function resource_title() {
		return $this->get_meta_value('resource_title');
	}

	function description() {
		return $this->content();
	}

	function resource_url() {
		return $this->get_meta_value( 'resource_url' );
	}


	function has_attachment() {
		return (bool) $this->attachment_id();
	}

	function attachment_id() {
		return $this->get_meta_value( 'attachment_id' );
	}

	function file_type() {

		$filetype = wp_check_filetype( $this->url() );

		switch ( $filetype['ext'] ) {

			case 'xls':
			case 'xlsx':
				return 'xls';

			case 'doc':
			case 'docx':
				return 'doc';

			case 'ppt':
			case 'pptx':
				return 'ppt';

			case 'pdf':
				return 'pdf';
		}

		return 'generic';
	}

	/**
	 * @param $resource_type string
	 */
	function set_resource_type( $resource_type ) {

		if ( KOAO::is_supported_resource_type( $resource_type ) ) {
			/*
			 * The sanitizer is 'raw', because we have already checked against the white-list.
			 */
			KOAO::update_post_meta( $this->ID(), 'resource_type', $resource_type, $sanitizer = 'raw' );
		}
	}

}
