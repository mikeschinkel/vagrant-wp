<?php
/**
 * @var KOAO_Theme $theme
 */

$theme->the_header_html();

_e( '404 - Page not found', 'koao-theme' );

$theme->the_footer_html();
