<footer class="footer-global row">
	<?php wp_nav_menu( array(
		'theme_location'  => 'main_menu',
		'container'       => 'nav',
		'container_class' => 'text-center',
		'depth'           => 1,
	) ); ?>
</footer>