<?php
/**
 * @var KOAO_Theme $theme
 */

$theme->the_header_html();
$theme->the_template( 'agency-type-header' );

/**
 * @todo Streamline this so get_term_by( 'slug', get_query_var( 'term' ), KOAO_Agency_Type::TAXONOMY ) is not required
 *       Should be much simplier and easier to understand.
 *       May require updates to WPLib.
 */
$agency_type = new KOAO_Agency_Type( get_term_by( 'slug', get_query_var( 'term' ), KOAO_Agency_Type::TAXONOMY ) );

?>

<div class="columns small-12">

	<div class="agency-type-inlay">

		<div class="row">

			<div class="columns large-6 medium-12">

				<div class="row collapse">

					<div class="columns medium-4">

						<?php $agency_type->the_image_html('koao-section-thumb', 'use_default=1'); ?>

					</div>

					<div class="columns medium-8">

						<div class="primary">

							<h4><?php esc_html_e( sprintf( _x( 'About %s', 'about agency type', 'koao-theme' ), $agency_type->term_name() ) ); ?></h4>

							<p><?php $agency_type->the_term_description_html(); ?></p>

							<?php $agency_type->the_learn_more_link(); ?>

						</div>

					</div>

				</div>

			</div>

			<div class="columns large-6 medium-12">
				<div class="details">
					<?php $agency_type->the_details_html(); ?>
				</div>
			</div>

		</div>

	</div>

</div>
<?php

	$agencies = KOAO::get_agency_list( array(), array(
		'agency_type_id' => $agency_type->term_id()
	));

	if ( empty( $agencies->elements() ) ) : ?>
		<ul class="card-collection small-block-grid-1 medium-block-grid-3 large-block-grid-4">
			<?php foreach ( $agencies as $agency ) : ?>
				<li>
					<?php $agency->the_template( 'cards/agency' ); ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<h5>
			<?php esc_html_e('There are no agencies of this type yet.', 'koao-theme'); ?>
		</h5>
	<?php endif; ?>

<?php $agency_type->the_template( 'agency-type-footer' );

$theme->the_footer_html();
