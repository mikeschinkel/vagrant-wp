<?php

/**
 * Class KOAO_Theme
 */
class KOAO_Theme extends WPLib_Theme_Base {

	/**
	 *
	 */
	static function on_load() {

		self::add_class_action( 'after_setup_theme' );
		self::add_class_action( 'wp_enqueue_scripts' );
		self::add_class_filter( 'query_monitor_conditionals' );

	}

	/**
	 * @param string[] $conditionals
	 *
	 * @return string[]
	 */
	static function _query_monitor_conditionals( $conditionals ) {

		global $wp_version;

		if ( version_compare( $wp_version, '4.5', '<=' ) ) {

			/**
			 * Remove 'is_comments_popup' from $conditionals in WP 4.5 or later
			 * @see http://stackoverflow.com/a/1883596/102699
			 */
			foreach ( array_keys( $conditionals, 'is_comments_popup' ) as $key ) {
				unset( $conditionals[ $key ] );
			}

		}
		return $conditionals;
	}

	/**
	 *
	 */
	static function _after_setup_theme() {

		add_theme_support( 'post-thumbnails' );

		add_image_size('koao-admin-thumb', 63, 63, true );
		add_image_size('koao-card-thumb',   130, 130, true );
		add_image_size('koao-section-thumb', 175, 175, true );

		register_nav_menu( 'main_menu', __( 'Main Menu', 'koao-theme' ) );

	}

	/**
	 *
	 */
	static function _wp_enqueue_scripts() {

		$suffix = WPLib::is_script_debug() ? '' : '.min';

		$assets_url = KOAO::theme()->assets_url();

		// Styles
		wp_enqueue_style( 'koao',   "{$assets_url}/css/main{$suffix}.css", array( 'vendor' ) );
		wp_enqueue_style( 'vendor', "{$assets_url}/css/vendor{$suffix}.css" );

		// Scripts
		wp_enqueue_script( 'koao',   "{$assets_url}/js/main{$suffix}.js",   array( 'vendor' ) );
		wp_enqueue_script( 'vendor', "{$assets_url}/js/vendor{$suffix}.js", array( 'jquery' ) );

		wp_localize_script('koao', 'KOAO_AJAX', array( 'url' => admin_url('admin-ajax.php') ));

	}

}
KOAO_Theme::on_load();
