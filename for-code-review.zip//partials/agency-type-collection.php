<?php

$agency_types = KOAO::agency_types_list();

if ( count( $agency_types ) ) : ?>
	<ul class="card-collection small-block-grid-1 medium-block-grid-3 large-block-grid-4">
		<?php foreach ( $agency_types as $agency_type ) : ?>
		<li>
			<?php $agency_type->the_template( 'cards/agency-type' ); ?>
		</li>
		<?php endforeach; ?>
	</ul><?php
endif;
