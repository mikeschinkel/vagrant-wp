<?php
/**
 * @var KOAO_Resource_Type[] $resource_types
 * @var KOAO_Theme $theme
 */
?>
<header class="header-local resources-header">

	<div class="row collapse">
		<div class="columns small-12">
			<?php WPLib::the_img( KOAO::get_themeable_asset_url('resources-header' ) ); ?>
		</div>
	</div>

	<div class="row collapse">

		<div class="row">

			<div class="banner-dark columns small-12">

				<nav class="text-center">
					<ul>
					<?php foreach ( KOAO::get_resource_type_list() as $resource_type ) : ?>
						<li>
							<?php
								WPLib::the_link(
									"#resource-type-{$resource_type->term_slug()}",
									$resource_type->term_name()
								);
							?>
						</li>
					<?php endforeach; ?>
					</ul>
				</nav>

			</div>

		</div>

	</div>

</header>