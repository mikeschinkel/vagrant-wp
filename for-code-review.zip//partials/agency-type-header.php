<?php
/**
 * @var KOAO_Theme $theme
 */
?>
<header class="header-local agency-type-header">

	<div class="row collapse">
		<div class="columns small-12">
			<?php WPLib::the_img( KOAO::get_themeable_asset_url('agencies-header' ) ); ?>
		</div>
	</div>

	<div class="row collapse">
		<div class="row">
			<div class="banner-dark columns small-12">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"
				   title="<?php esc_attr_e('Click to see the list of all agency categories', 'koao-theme'); ?>">
					<i class="fa fa-caret-left fa-2x"></i> <?php esc_html_e( 'Back to All', 'koao-theme' ); ?>
				</a>
			</div>
		</div>
	</div>

</header>