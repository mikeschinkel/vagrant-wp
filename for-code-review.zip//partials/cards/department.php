<?php
/**
 * @var KOAO_Department $item
 */
?>
<div class="card card-type-person-department table">

	<a href="<?php $item->the_permalink_url(); ?>">

		<div class="table-row">
			<div class="table-cell">
				<?php $item->the_image_html(); ?>
			</div>
			<div class="table-cell text-center">
				<div class="person-department-title"><?php $item->the_term_name_html(); ?></div>
			</div>
		</div>

	</a>

</div>