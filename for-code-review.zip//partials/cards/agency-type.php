<?php
/**
 * @var KOAO_Agency_Type $item
 */
?>
<div class="card card-type-agency-type">

	<a href="<?php $item->the_permalink_url(); ?>"
	   title="<?php esc_attr_e('Click to see agencies in this category', 'koao-theme'); ?>">

		<div class="row collapse">
			<div class="small-4 columns">
				<?php $item->the_image_html('koao-card-thumb', 'use_default=1'); ?>
			</div>
			<div class="small-8 columns text-center middle">
				<div class="agency-type-title">
					<?php $item->the_term_name_html(); ?>
				</div>
			</div>
		</div>

	</a>

</div>