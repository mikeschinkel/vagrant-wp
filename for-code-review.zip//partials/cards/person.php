<?php
/**
 * @var KOAO_Person $person
 */
?>
<div class="card card-type-person table">
	<div class="table-row row collapse">
		<div class="small-3 columns person-photo table-cell">
			<?php $person->the_featured_image_html( 'koao-card-thumb' ); ?>
		</div>
		<div class="small-5 columns table-cell table-cell">
			<div class="person-header">
				<h5><?php $person->the_position_html(); ?></h5>
				<div class="person-name"><?php $person->the_full_name_html(); ?></div>
			</div>
			<div class="person-details">
				<h5><?php esc_html_e('Contact Info', 'koao-theme'); ?></h5>
				<?php $person->the_contacts_html(); ?>
			</div>
		</div>
		<div class="small-4 columns person-categories table-cell">
			<h5><?php esc_html_e('Categories', 'koao-theme'); ?></h5>
			<?php $person->the_categories_html(); ?>
		</div>
	</div>
</div>
