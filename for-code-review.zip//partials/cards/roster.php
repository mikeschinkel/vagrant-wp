<?php
/**
 * @var KOAO_Agency_Type $agency_type
 */
?>
<div class="card card-type-roster table">
  <a href="<?php $agency_type->the_roster_file_url(); ?>"
     title="<?php esc_attr_e('Click to download agency rates in a CSV file', 'koao-theme' )?>">
	<div class="table-row row collapse">
		<div class="small-5 columns roster-icon table-cell">
			<img src="<?php echo KOAO::get_themeable_asset_url('csv-file-type-icon' ); ?>" />
		</div>
		<div class="small-7 columns roster-title table-cell">
			<p><?php printf( __('%s<br>COE Roster', 'roster card','koao-theme' ), $agency_type->term_name() ); ?></p>
		</div>
	</div>
  </a>
</div>
