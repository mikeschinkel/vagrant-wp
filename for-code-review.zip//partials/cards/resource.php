<?php
/**
 * @var $item KOAO_Resource
 */
?>
<div class="card card-type-resource table">

	<a href="<?php $item->the_resource_url_attr(); ?>">

		<div class="table-row">
			<div class="table-cell">
				<?php $item->the_featured_image_html( 'thumbnail' ); ?>
			</div>
			<div class="table-cell">
				<div class="resource-title"><?php $item->the_title_html('before=&after='); ?></div>
			</div>
		</div>
		<div class="back hide animated flipInX">
			<?php $item->the_content_html(); ?>
		</div>
		<i class="fa fa-question-circle fa-2x"></i>

	</a>
</div>