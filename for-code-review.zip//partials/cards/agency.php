<?php
/**
 * @var KOAO_Agency $agency
 * @var KOAO_Theme $theme
 */

?>
<div class="card card-type-agency table">
	<a href="<?php $agency->the_permalink(); ?>"
	   title="<?php esc_attr_e('Click to see more details about this agency', 'koao-theme'); ?>">
		<div class="table-row row collapse">
			<div class="table-cell small-6 columns">
				<?php $agency->the_featured_image_html( 'koao-card-thumb' ); ?>
			</div>
			<div class="table-cell small-6 columns text-center">
				<div class="agency-name"><?php $agency->the_agency_name_attr(); ?></div>
				<div class="agency-details">
					<div class="agency-type"><?php $agency->the_agency_types_html(); ?></div>
					<div class="agency-subcategory"><?php $agency->the_subcategory_html(); ?></div>
				</div>
			</div>
		</div>
	</a>
</div>
