<?php
/**
 * @var $agency KOAO_Agency
 */
join( '<br />', array_filter( array(
	$agency->street_address(),
	$agency->address_line_2(),
	join( ' ', array_filter( array(
		join( ', ', array_filter( array(
			$agency->address_locality(),
			$agency->address_region(),
		) ) ),
		$agency->postal_code(),
	) ) ),
) ) );