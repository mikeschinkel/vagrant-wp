<div class="exception-request-cta">
	<p>
		<?php esc_html_e( 'Can\'t find the agency you want to use?', 'koao-theme' ); ?>
	</p>
	<a class="button radius magnific-popup-link exception-request"  data-mfp-src="#new-exception-request"
	        title="<?php esc_attr_e('Click to fill in an exception request form', 'koao-theme'); ?>">
		<?php esc_html_e( 'Request an exception', 'koao-theme' ); ?> <i class="fa fa-caret-right"></i>
	</a>

	<div id="new-exception-request" class="form-popup mfp-hide">
		<div class="entry-form">

			<h3><span>
				<?php esc_html_e( 'Exception Request', 'koao-theme' ); ?>
			</span></h3>

			<?php KOAO::the_frontend_editable_form_html(); ?>

			<button class="jq-submit button radius">
				<?php esc_html_e('Submit Request', 'koao-theme'); ?>
			</button>

			<p class="jq-message"></p>

		</div>

		<div class="success-form hide">
			<h1><?php esc_html_e( 'Thank you for your submission!', 'koao-theme' ); ?></h1>

			<p><?php esc_html_e( 'We will contact you once your request has been processed.', 'koao-theme' ); ?></p>

			<p>
				<strong><?php esc_html_e( 'Please Note:', 'koao-theme' ); ?></strong>
				<?php esc_html_e( 'Exception requests may take up to 2 weeks to be processed as each Request
					   must be evaluated by the appropriate Steering Committee or Center of Excellence.', 'koao-theme' ); ?>

				<em><?php esc_html_e( 'Marketers should not engage agency until the exception request has been processed.', 'koao-theme' ); ?></em>
			</p>
			<button class="jq-close radius"><?php esc_html_e('Close', 'koao-theme' ); ?></button>
		</div>
	</div>
</div>
