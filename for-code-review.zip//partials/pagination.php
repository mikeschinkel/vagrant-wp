<?php
/**
 * @var $agency_type KOAO_Agency_Type
 */
?>
<div class="pagination">

	<?php

	$total_pages = KOAO::get_agencies_total_pages( array(
			'posts_per_page'  => KOAO_Agencies::POSTS_PER_PAGE,
			'agency_type_id'  => $agency_type->term_id()
	));

	if ( $total_pages > 1 ) : ?>

		<span class="arrow prev">
			<a href="#" class="button-dark button radius"
			   title="<?php esc_attr_e('Previous page', 'koao-theme'); ?>"><i class="fa fa-caret-left"></i>
			</a>
		</span>

		<span class="details"
		      data-current-page="1"
		      data-posts-per-page="<?php echo KOAO_Agencies::POSTS_PER_PAGE; ?>"
		      data-total-pages="<?php echo $total_pages; ?>"
		      data-agency-type-id="<?php echo $agency_type->term_id(); ?>"
		      data-template="<?php esc_attr_e( _x('%1$d of %2$d', 'agency pagination info', 'koao-theme')); ?>"
	    >
			<?php printf( esc_html_x('%1$d of %2$d', 'agency pagination info', 'koao-theme'), 1, $total_pages ); ?>
		</span>

		<span class="arrow next">
			<a href="#" class="button-dark button radius"
			   title="<?php esc_attr_e('Next page', 'koao-theme'); ?>"><i class="fa fa-caret-right"></i>
			</a>
		</span>	<?php

	endif; ?>

</div>
