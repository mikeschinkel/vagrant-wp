<?php

/**
 * @var KOAO_Site_Update[] $site_updates
 */
$site_updates = KOAO::site_updates_list();

$count_updates = count( $site_updates );

if ( $count_updates ) :
	$is_paging = $count_updates > 1; ?>

<div class="updates-slider">
	<div class="update-banner row">

		<div class="columns <?php echo $is_paging ? 'medium-4 large-3' : 'medium-3 large-2'; ?>">
			<div class="row">
				<?php if ( $is_paging ) : ?>
				<div class="columns small-6 pagination text-center">
					<i id="updates-slider-prev" class="fa fa-caret-left"></i>
					<span class="pagination-text"
					      data-count-slides="<?php echo $count_updates; ?>"
					      data-text-template="<?php esc_attr_e( _x( '{current} of {total}', 'pagination information -- do not translate the terms in curly braces!', 'koao-theme' ));?>">
						<?php printf( __('1 of %d', 'koao-theme'), $count_updates); ?>
					</span>
					<i id="updates-slider-next" class="fa fa-caret-right"></i>
				</div>
				<?php endif; ?>
				<div class="columns <?php echo $is_paging ? 'small-6' : 'small-12'; ?> text-center">
					<?php esc_html_e( 'SITE UPDATES', 'koao-theme' ); ?>
				</div>
			</div>
		</div>

		<div class="columns <?php echo $is_paging ? 'medium-8 large-9' : 'medium-9 large-10'; ?>">
			<div class="update-text text-center">
				<div id="updates-slider">
					<?php foreach ( $site_updates as $site_update ) : ?>
						<div>
							<?php $site_update->the_content_html(); ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>

		<span class="close text-right" title="<?php esc_html_e('Hide site updates', 'koao-theme'); ?>">
			<span class="show-for-sr"><?php esc_html_e( 'Close', 'koao-theme' ); ?></span>
			<i class="fa fa-times"></i>
		</span>

	</div>
</div> <?php

endif;
