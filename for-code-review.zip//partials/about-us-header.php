<?php
/**
 * @var KOAO_Theme $theme
 */
?>
<header class="header-local about-us-header">

	<div class="row collapse">
		<div class="columns small-12">
			<?php WPLib::the_img( KOAO::get_themeable_asset_url('about-us-header' ) ); ?>
		</div>
	</div>

	<div class="row collapse">

		<div class="row">

			<div class="banner-dark columns small-12">

				<nav class="text-center">
					<ul>
						<?php foreach ( KOAO::departments_list() as $department ) : ?>

							<li><a href="#<?php $department->the_term_slug_attr(); ?>"><?php $department->the_term_name_html(); ?></a></li>

						<?php endforeach; ?>

						<li><a href="#coe"><?php esc_html_e( 'COE', 'koao-theme' ); ?></a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
</header>
