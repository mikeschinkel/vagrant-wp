<div class="homepage-slider">
	<?php foreach ( KOAO::featured_slides_list() as $slide ) : ?>
		<div>
			<?php $slide->the_featured_image_html( 'full' ); ?>
		</div>
	<?php endforeach; ?>
</div>
