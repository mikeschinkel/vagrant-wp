<?php
/**
 * @var $agency_type KOAO_Agency_Type
 */
?>
<footer class="footer-local agency-type-footer row">

	<?php if ( KOAO::current_user_can_download_roster_files() ) : ?>
	<div class="columns large-4 text-center roster-cta">
		<a class="button-dark button radius" href="<?php $agency_type->the_roster_file_url(); ?>"
		   title="<?php esc_attr_e('Click to download agency rates in a CSV file', 'koao-theme'); ?>">
			<?php esc_html_e( 'Download Roster', 'koao-theme' ); ?> <i class="fa fa-download"></i>
		</a>
	</div>
	<?php endif; ?>

	<div class="columns large-4">
		<div class="pagination-centered">
			<?php $agency_type->the_template( '/pagination' ); ?>
		</div>
	</div>

	<div class="columns large-4">
		<?php $agency_type->the_template( '/exception-request' ); ?>
	</div>

</footer>
