<?php
/**
 * @var KOAO_Theme $theme
 */

$theme->the_header_html();
$theme->the_template( 'homepage-slider' );

?>

<div class="homepage-banner text-center"><?php esc_html_e( 'Choose an agency category', 'koao-theme' ); ?></div>

<?php

$theme->the_template( 'updates-slider' );
$theme->the_template( 'agency-type-collection' );
$theme->the_template( 'exception-request' );

$theme->the_footer_html();
