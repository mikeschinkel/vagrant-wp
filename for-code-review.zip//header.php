<!DOCTYPE html>
<html <?php language_attributes(); ?>>

	<head>
		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>

		<div class="page">

			<?php get_header( 'content' ); ?>

			<main role="main" class="row">