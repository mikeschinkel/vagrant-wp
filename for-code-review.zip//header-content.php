<header class="header-global">

	<div class="row">

		<div class="columns medium-4">
			<a href="<?php echo home_url('/'); ?>" title="<?php esc_attr_e( get_bloginfo('name') ); ?>">
				<img src="<?php echo KOAO::get_themeable_asset_url( 'site-logo' ); ?>" class="coke-logo">
			</a>
		</div>

		<div class="columns medium-8">
			<?php wp_nav_menu( array(
				'theme_location'  => 'main_menu',
				'container'       => 'nav',
				'container_class' => 'text-right',
				'depth'           => 1,
			) ); ?>
		</div>

	</div>

</header>