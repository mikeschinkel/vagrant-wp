<?php

/*
 * Template Name: Resources Page
 */

/**
 * @var KOAO_Theme $theme
 * @var KOAO_Resource_Type $resource_type
 * @var KOAO_Resource $resource
 */

$theme->the_header_html();
$theme->the_template( 'resources-header' );

foreach ( KOAO::get_resource_type_list() as $resource_type ) :
	?>

	<div class="columns small-12">

		<div id="resource-type-<?php $resource_type->the_term_slug_attr(); ?>" class="inlay resources-inlay">

			<h4><?php $resource_type->the_term_name(); ?></h4>

			<p><?php $resource_type->the_term_description(); ?></p>

		</div>

	</div>


	<ul class="card-collection small-block-grid-1 medium-block-grid-3 large-block-grid-4">

		<?php
		foreach ( $resource_type->resources_list() as $resource ) :
			?>
			<li>
				<?php $resource->the_template( '/cards/resource' ); ?>
			</li>
			<?php
		endforeach;
		?>

	</ul>

<?php
endforeach;

$theme->the_footer_html();
