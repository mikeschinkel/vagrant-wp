<?php

/*
 * Template Name: Agency Type
 */

/**
 * @var KOAO_Theme $theme
 * @var KOAO_Agency $agency
 * @var KOAO_Person[] $persons
 */

$agency_type = new KOAO_Agency_Type( get_term_by( 'slug', get_query_var( 'term' ), KOAO_Agency_Type::TAXONOMY ) );

$theme->the_header_html();
$theme->the_template( 'agency-type-header' );
?>

<div class="columns small-12">

	<div class="agency-type-inlay">

		<div class="row">

			<div class="columns large-6 medium-12">

				<div class="row">

					<div class="columns medium-4">

						<?php $agency_type->the_image_html( 'medium' ); ?>

					</div>

					<div class="columns medium-8">

						<h4><?php echo esc_html( sprintf( __( 'About %s', 'koao-theme' ), $agency_type->term_name() ) ); ?></h4>

						<p><?php $agency_type->the_term_description(); ?></p>

						<?php $agency_type->the_learn_more_link(); ?>

					</div>

				</div>

			</div>

			<div class="columns large-6 medium-12">
				<?php $agency_type->the_details_html(); ?>
			</div>

		</div>

	</div>

</div>

<?php if ( ! $agency_type->has_agencies() ) : ?>

	<h5><?php esc_html_e('There are no agencies of this type yet.', 'koao-theme'); ?></h5>

<?php else : ?>

	<ul class="card-collection small-block-grid-1 medium-block-grid-3 large-block-grid-4">

	<?php foreach ( $agency_type->agency_list() as $agency ) :	?>
		<li>
			<?php $agency->the_template( 'cards/agency' ); ?>
		</li>
	<?php endforeach; ?>

	</ul>

<?php endif;

$theme->the_template( 'agency-type-footer' );
$theme->the_footer_html();
