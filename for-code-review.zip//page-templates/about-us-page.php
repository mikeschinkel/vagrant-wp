<?php
/*
 * Template Name: About Us Page
 */

/**
 * @var KOAO_Theme $theme
 * @var KOAO_Department $department
 * @var KOAO_Person[] $persons
 */

$theme->the_header_html();

$theme->the_template( 'about-us-header' ); ?>

<?php foreach ( KOAO::departments_list() as $department ) : ?>

	<div class="columns small-12">

		<div class="inlay departments-inlay">

			<h5 id="<?php $department->the_term_slug_attr(); ?>"><?php $department->the_term_name_html(); ?></h5>

			<p><?php $department->the_term_description_html(); ?></p>

		</div>

	</div>

	<?php if ( count( $persons = $department->people_list() ) ) : ?>

		<ul class="card-collection small-block-grid-1 medium-block-grid-2">

			<?php foreach ( $persons as $person ) : ?>
			<li>
				<?php $person->the_template( 'cards/person' ); ?>
			</li>
			<?php endforeach; ?>

		</ul>

	<?php endif; ?>

<?php endforeach; //each department ?>

<?php if ( count( $agency_types = KOAO::get_agency_types_list( 'hide_empty=1' ) )) : ?>

	<div id="coe" class="columns small-12">

		<div class="inlay departments-inlay">

			<h5><?php esc_html_e('Centers of Operational Excellence','koao-theme'); ?></h5>

			<p><?php /* TODO: add description */ ?></p>

		</div>

	</div>

	<ul class="card-collection small-block-grid-1 medium-block-grid-3 large-block-grid-4">
	<?php foreach ( $agency_types as $agency_type ) : ?>
		<li>
			<?php $agency_type->the_template( 'cards/roster' ); ?>
		</li>
	<?php endforeach; ?>
	</ul>

<?php endif; ?>

<?php $theme->the_footer_html();
