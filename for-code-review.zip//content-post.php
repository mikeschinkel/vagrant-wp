<header class="header-local"></header>

<article <?php post_class(); ?>></article>

<footer class="footer-local"></footer>