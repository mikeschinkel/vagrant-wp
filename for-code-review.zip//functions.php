<?php

//require __DIR__ . '/vendor/autoload.php';

require __DIR__ . '/vendor/wplib/wplib/defines.php';
wplib_define( 'WPLib_Runmode',   'DEVELOPMENT' );
wplib_define( 'WPLib_Stability', 'EXPERIMENTAL' );
define( 'WPLIB_TEMPLATES_SUBDIR', 'partials' );

require __DIR__ . '/vendor/wplib/wplib/wplib.php';
WPLib::initialize();

require __DIR__ . '/app/koao.php';
KOAO::initialize();

require __DIR__ . '/koao-theme.php';

//KOAO::register_taxonomy_default_image(
//	KOAO_Agency_Type::TAXONOMY,
	//'images/empty-term.png'
//);
